# ReplyFlow AI — Instagram Automation SaaS

> Full-stack Next.js 15 SaaS for Instagram DM, comment & story automation with Indian payment support.

![ReplyFlow AI](https://via.placeholder.com/1200x630/7c3aed/ffffff?text=ReplyFlow+AI)

---

## 🚀 Tech Stack

| Layer       | Technology                              |
|-------------|----------------------------------------|
| Framework   | Next.js 15 (App Router)                |
| Styling     | Tailwind CSS + Framer Motion           |
| Auth        | Clerk (Email + Google OAuth)           |
| Database    | PostgreSQL + Prisma ORM                |
| Payments    | Razorpay · PhonePe · Stripe            |
| UPI         | 7673962811@ybl                         |
| AI          | OpenAI GPT-4 (AI Reply Assistant)      |
| Deployment  | Vercel                                 |

---

## 📁 Project Structure

```
replyflow-ai/
├── prisma/
│   ├── schema.prisma          # Full DB schema
│   └── seed.ts                # Demo data seeder
├── src/
│   ├── app/
│   │   ├── page.tsx           # Landing page
│   │   ├── pricing/           # Standalone pricing page
│   │   ├── login/             # Clerk SignIn
│   │   ├── signup/            # Clerk SignUp
│   │   ├── dashboard/         # Protected dashboard
│   │   │   ├── layout.tsx     # Sidebar layout
│   │   │   ├── page.tsx       # Overview
│   │   │   ├── automations/   # Automation CRUD
│   │   │   ├── analytics/     # Charts & metrics
│   │   │   ├── billing/       # Subscription & payments
│   │   │   ├── settings/      # Instagram, profile, notifs
│   │   │   └── help/          # Help center & FAQ
│   │   ├── admin/             # Admin panel
│   │   ├── payment-success/   # Post-payment success
│   │   ├── payment-failed/    # Failed payment page
│   │   └── api/
│   │       ├── trial/         # Trial management
│   │       ├── automations/   # Automation CRUD API
│   │       ├── razorpay/      # Payment create + verify
│   │       ├── phonepe/       # PhonePe initiate + callback
│   │       ├── stripe/        # Stripe webhook
│   │       ├── analytics/     # Stats & chart data
│   │       ├── users/         # User data APIs
│   │       ├── admin/         # Admin APIs
│   │       └── webhooks/      # Clerk webhook
│   ├── components/
│   │   └── ui/
│   │       └── theme-provider.tsx
│   ├── hooks/
│   │   └── use-trial.ts       # Zustand trial state
│   ├── lib/
│   │   ├── prisma.ts          # Prisma client singleton
│   │   └── plans.ts           # Plan config & pricing
│   └── middleware.ts          # Clerk route protection
├── .env.example               # All env variables listed
├── next.config.js
├── tailwind.config.js
└── tsconfig.json
```

---

## ⚡ Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourusername/replyflow-ai.git
cd replyflow-ai
npm install
```

### 2. Set up Environment Variables

```bash
cp .env.example .env.local
# Fill in all values (see sections below)
```

### 3. Set up Database

```bash
# Start PostgreSQL (local or Supabase/Neon)
npx prisma generate
npx prisma db push
npm run db:seed
```

### 4. Run Development Server

```bash
npm run dev
# Open http://localhost:3000
```

---

## 🔑 Environment Setup Guide

### Clerk Authentication
1. Go to [clerk.com](https://clerk.com) → Create application
2. Enable Email + Google social login
3. Copy `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` and `CLERK_SECRET_KEY`
4. Set up webhook: `https://yourdomain.com/api/webhooks/clerk`
   - Events: `user.created`, `user.updated`, `user.deleted`
   - Copy signing secret → `CLERK_WEBHOOK_SECRET`

### Razorpay (Primary Indian Payments)
1. Sign up at [razorpay.com](https://razorpay.com)
2. Dashboard → Settings → API Keys → Generate Key
3. Copy `Key ID` → `RAZORPAY_KEY_ID` and `NEXT_PUBLIC_RAZORPAY_KEY_ID`
4. Copy `Key Secret` → `RAZORPAY_KEY_SECRET`
5. Create 3 plans in Razorpay Dashboard:
   - Starter: ₹499/month → copy plan ID → `RAZORPAY_PLAN_STARTER`
   - Pro: ₹999/month → `RAZORPAY_PLAN_PRO`
   - Agency: ₹2499/month → `RAZORPAY_PLAN_AGENCY`

### PhonePe Integration
1. Register at [developer.phonepe.com](https://developer.phonepe.com)
2. Get sandbox credentials first
3. Set `PHONEPE_MERCHANT_ID`, `PHONEPE_SALT_KEY`, `PHONEPE_SALT_INDEX`
4. Set `PHONEPE_ENV=sandbox` for testing, `production` for live

### Meta / Instagram API
1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Create app → Add Instagram Graph API product
3. Configure OAuth redirect: `https://yourdomain.com/api/instagram/callback`
4. Required permissions: `instagram_basic`, `instagram_manage_messages`, `instagram_manage_comments`
5. Copy App ID → `NEXT_PUBLIC_INSTAGRAM_APP_ID`
6. Copy App Secret → `INSTAGRAM_APP_SECRET`

### Stripe (International Payments)
1. Sign up at [stripe.com](https://stripe.com)
2. Get API keys from Dashboard → Developers → API Keys
3. Create 3 prices for monthly subscriptions
4. Set up webhook: `https://yourdomain.com/api/stripe/webhook`
   - Events: `checkout.session.completed`, `invoice.payment_failed`, `customer.subscription.*`

---

## 💳 Indian Payment Flow

```
User clicks "Pay" →
  → Razorpay Checkout opens
  → User selects UPI / PhonePe / Google Pay / Card / Net Banking
  → Payment processed via Razorpay
  → razorpay_signature verified server-side (HMAC SHA256)
  → Subscription activated in DB
  → Invoice generated
  → User redirected to /payment-success
```

**UPI ID for payments:** `7673962811@ybl`

**PhonePe flow:**
```
POST /api/phonepe/initiate → redirects to PhonePe payment page
PhonePe → POST /api/phonepe/callback (verified via SHA256 checksum)
```

---

## 🚢 Vercel Deployment

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# Set env variables in Vercel Dashboard → Settings → Environment Variables
# Add all variables from .env.example
```

**Vercel Settings:**
- Framework: Next.js
- Node version: 18.x or 20.x
- Build command: `npm run build`
- Add `DATABASE_URL` pointing to production PostgreSQL (Supabase/Neon/PlanetScale)

---

## 📊 Subscription Plans

| Plan     | Price      | Accounts | AutoDMs/day |
|----------|------------|----------|-------------|
| Starter  | ₹499/month | 1        | 500         |
| Pro      | ₹999/month | 5        | 5,000       |
| Agency   | ₹2,499/mo  | Unlimited| Unlimited   |

- **Trial**: 7 days free, full Pro access, no card required
- **Auto-renew**: Monthly billing via Razorpay subscriptions
- **Upgrade/Downgrade**: Instant via billing dashboard

---

## 🔐 Security

- JWT session management via Clerk
- Razorpay signature verification (HMAC SHA256)
- PhonePe checksum validation
- Instagram access tokens encrypted at rest
- Admin routes protected by role check
- Rate limiting on payment APIs
- Webhook signature validation (Svix for Clerk, Stripe-signature for Stripe)

---

## 🧰 Scripts

```bash
npm run dev          # Start dev server
npm run build        # Production build
npm run start        # Start production server
npm run db:push      # Push schema to DB
npm run db:migrate   # Run migrations
npm run db:studio    # Open Prisma Studio
npm run db:seed      # Seed demo data
```

---

## 📞 Support

- Email: support@replyflow.ai
- Docs: docs.replyflow.ai
- UPI: 7673962811@ybl

---

**Made with ❤️ in India** | Built for Indian creators & businesses
