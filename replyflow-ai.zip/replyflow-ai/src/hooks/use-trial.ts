// src/hooks/use-trial.ts
import { create } from 'zustand';

interface TrialState {
  status:        'loading' | 'trial' | 'active' | 'expired' | 'no_trial';
  daysRemaining: number | null;
  hoursRemaining: number | null;
  expiresAt:     string | null;
  plan:          string | null;
  isLoaded:      boolean;
  setTrial:      (data: Partial<TrialState>) => void;
  fetchTrial:    () => Promise<void>;
}

export const useTrialStore = create<TrialState>((set) => ({
  status:         'loading',
  daysRemaining:  null,
  hoursRemaining: null,
  expiresAt:      null,
  plan:           null,
  isLoaded:       false,

  setTrial: (data) => set(data),

  fetchTrial: async () => {
    try {
      const res  = await fetch('/api/trial');
      const data = await res.json();
      set({
        status:         data.status,
        daysRemaining:  data.daysRemaining,
        hoursRemaining: data.hoursRemaining,
        expiresAt:      data.expiresAt,
        plan:           data.plan,
        isLoaded:       true,
      });
    } catch {
      set({ status: 'no_trial', isLoaded: true });
    }
  },
}));
