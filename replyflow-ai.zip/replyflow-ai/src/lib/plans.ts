// src/lib/plans.ts
// Single source of truth for all plan data

export type PlanId = 'starter' | 'pro' | 'agency';

export interface PlanFeature {
  text: string;
  included: boolean;
  highlight?: boolean;
}

export interface Plan {
  id: PlanId;
  name: string;
  tagline: string;
  price: number;        // INR per month
  priceDisplay: string;
  period: string;
  badge?: string;
  badgeColor?: string;
  popular: boolean;
  accentColor: string;
  gradientFrom: string;
  gradientTo: string;
  features: PlanFeature[];
  instagramAccounts: string;
  cta: string;
  razorpayPlanId?: string; // set in env
  stripePriceId?: string;
}

export const PLANS: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    tagline: 'Perfect for creators & solopreneurs',
    price: 499,
    priceDisplay: '₹499',
    period: '/month',
    popular: false,
    accentColor: '#7c3aed',
    gradientFrom: '#7c3aed',
    gradientTo: '#a855f7',
    instagramAccounts: '1 Instagram Account',
    cta: 'Start Free Trial',
    razorpayPlanId: process.env.RAZORPAY_PLAN_STARTER,
    stripePriceId: process.env.STRIPE_PRICE_STARTER,
    features: [
      { text: '1 Instagram Account',          included: true  },
      { text: 'Unlimited AutoDM',              included: true  },
      { text: 'Comment Automation',            included: true  },
      { text: 'Story Reply Automation',        included: true  },
      { text: 'Welcome DM Automation',         included: true  },
      { text: 'Basic Analytics Dashboard',     included: true  },
      { text: 'Keyword Trigger Automation',    included: true  },
      { text: 'AI Reply Assistant',            included: false },
      { text: 'Advanced Analytics',            included: false },
      { text: 'Priority Support',              included: false },
      { text: 'Team Access',                   included: false },
      { text: 'API Access',                    included: false },
      { text: 'White-label Support',           included: false },
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'For serious businesses & agencies',
    price: 999,
    priceDisplay: '₹999',
    period: '/month',
    badge: 'Most Popular',
    badgeColor: '#ff2d78',
    popular: true,
    accentColor: '#d946ef',
    gradientFrom: '#7c3aed',
    gradientTo: '#ff2d78',
    instagramAccounts: '5 Instagram Accounts',
    cta: 'Start Free Trial',
    razorpayPlanId: process.env.RAZORPAY_PLAN_PRO,
    stripePriceId: process.env.STRIPE_PRICE_PRO,
    features: [
      { text: '5 Instagram Accounts',          included: true, highlight: true },
      { text: 'Unlimited AutoDM',              included: true  },
      { text: 'Comment Automation',            included: true  },
      { text: 'Story Reply Automation',        included: true  },
      { text: 'Welcome DM Automation',         included: true  },
      { text: 'Advanced Analytics Dashboard',  included: true, highlight: true },
      { text: 'Keyword Trigger Automation',    included: true  },
      { text: 'AI Reply Assistant',            included: true, highlight: true },
      { text: 'Lead Capture in DMs',           included: true  },
      { text: 'Priority Support',              included: true, highlight: true },
      { text: 'Team Access',                   included: false },
      { text: 'API Access',                    included: false },
      { text: 'White-label Support',           included: false },
    ],
  },
  {
    id: 'agency',
    name: 'Agency',
    tagline: 'Scale without limits',
    price: 2499,
    priceDisplay: '₹2,499',
    period: '/month',
    badge: 'Best Value',
    badgeColor: '#f59e0b',
    popular: false,
    accentColor: '#f59e0b',
    gradientFrom: '#d97706',
    gradientTo: '#f59e0b',
    instagramAccounts: 'Unlimited Accounts',
    cta: 'Start Free Trial',
    razorpayPlanId: process.env.RAZORPAY_PLAN_AGENCY,
    stripePriceId: process.env.STRIPE_PRICE_AGENCY,
    features: [
      { text: 'Unlimited Instagram Accounts',  included: true, highlight: true },
      { text: 'Unlimited AutoDM',              included: true  },
      { text: 'All Automation Types',          included: true  },
      { text: 'Advanced Analytics Dashboard',  included: true  },
      { text: 'AI Reply Assistant',            included: true  },
      { text: 'Lead Capture in DMs',           included: true  },
      { text: 'Team Access (Unlimited)',        included: true, highlight: true },
      { text: 'API Access',                    included: true, highlight: true },
      { text: 'White-label Support',           included: true, highlight: true },
      { text: 'Full Analytics + Export',       included: true  },
      { text: 'Dedicated Account Manager',     included: true, highlight: true },
      { text: 'SLA Priority Support',          included: true  },
      { text: 'Custom Integrations',           included: true  },
    ],
  },
];

export const TRIAL_DAYS = 7;

export const PLAN_LIMITS: Record<PlanId, { accounts: number; automations: number; dmsPerDay: number }> = {
  starter: { accounts: 1,  automations: 10,  dmsPerDay: 500  },
  pro:     { accounts: 5,  automations: 50,  dmsPerDay: 5000 },
  agency:  { accounts: -1, automations: -1,  dmsPerDay: -1   }, // -1 = unlimited
};

// Indian payment display configs
export const PAYMENT_METHODS = [
  {
    id: 'upi',
    label: 'UPI / QR Code',
    icon: '/icons/upi.svg',
    description: 'PhonePe, Google Pay, Paytm & all UPI apps',
    popular: true,
  },
  {
    id: 'phonepe',
    label: 'PhonePe',
    icon: '/icons/phonepe.svg',
    description: 'Pay instantly with PhonePe',
    popular: false,
  },
  {
    id: 'googlepay',
    label: 'Google Pay',
    icon: '/icons/gpay.svg',
    description: 'Pay with Google Pay',
    popular: false,
  },
  {
    id: 'card',
    label: 'Credit / Debit Card',
    icon: '/icons/card.svg',
    description: 'Visa, Mastercard, RuPay',
    popular: false,
  },
  {
    id: 'netbanking',
    label: 'Net Banking',
    icon: '/icons/bank.svg',
    description: 'All major Indian banks',
    popular: false,
  },
] as const;

export type PaymentMethodId = (typeof PAYMENT_METHODS)[number]['id'];
