// src/app/layout.tsx
import type { Metadata } from 'next';
import { Syne, DM_Sans, JetBrains_Mono } from 'next/font/google';
import { ClerkProvider } from '@clerk/nextjs';
import { ThemeProvider } from '@/components/ui/theme-provider';
import { Toaster } from 'react-hot-toast';
import './globals.css';

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '500', '600', '700', '800'],
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  weight: ['300', '400', '500', '600', '700'],
  display: 'swap',
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  weight: ['400', '500'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'ReplyFlow AI — Instagram Automation Platform',
    template: '%s | ReplyFlow AI',
  },
  description:
    'Automate Instagram DMs, comments, story replies & lead generation with AI. Grow your business on autopilot.',
  keywords: [
    'instagram automation',
    'auto dm',
    'instagram bot',
    'comment automation',
    'lead generation instagram',
    'instagram marketing',
    'replyflow',
  ],
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://replyflow.ai'),
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://replyflow.ai',
    siteName: 'ReplyFlow AI',
    title: 'ReplyFlow AI — Instagram Automation Platform',
    description: 'Automate Instagram DMs, comments & leads with AI. 7-day free trial.',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ReplyFlow AI',
    description: 'Automate Instagram DMs & grow on autopilot.',
    images: ['/og-image.png'],
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" suppressHydrationWarning>
        <body className={`${syne.variable} ${dmSans.variable} ${jetbrains.variable} font-body antialiased`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            enableSystem={false}
            disableTransitionOnChange
          >
            {children}
            <Toaster
              position="top-right"
              toastOptions={{
                style: {
                  background: '#1a1a2e',
                  color: '#fff',
                  border: '1px solid rgba(124,58,237,0.3)',
                  borderRadius: '12px',
                  fontFamily: 'var(--font-dm-sans)',
                },
                success: { iconTheme: { primary: '#d946ef', secondary: '#fff' } },
                error: { iconTheme: { primary: '#ff2d78', secondary: '#fff' } },
              }}
            />
          </ThemeProvider>
        </body>
      </html>
    </ClerkProvider>
  );
}
