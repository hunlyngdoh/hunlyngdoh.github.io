// src/app/login/page.tsx
import { SignIn } from '@clerk/nextjs';
import Link from 'next/link';
import { Zap } from 'lucide-react';

export const metadata = { title: 'Sign In — ReplyFlow AI' };

export default function LoginPage() {
  return (
    <div className="min-h-screen mesh-gradient flex flex-col items-center justify-center p-4">
      {/* Background orbs */}
      <div className="absolute w-96 h-96 -top-20 -left-20 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute w-80 h-80 -bottom-10 -right-10 bg-pink-500/8 rounded-full blur-3xl pointer-events-none" />

      {/* Logo */}
      <Link href="/" className="flex items-center gap-2.5 mb-8 relative z-10">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center shadow-glow-sm">
          <Zap className="w-4.5 h-4.5 text-white" fill="white" />
        </div>
        <span className="font-display font-bold text-xl tracking-tight">
          Reply<span className="text-gradient">Flow</span> AI
        </span>
      </Link>

      {/* Clerk SignIn */}
      <div className="relative z-10">
        <SignIn
          appearance={{
            layout: { socialButtonsPlacement: 'top', socialButtonsVariant: 'iconButton' },
            elements: {
              rootBox:              'w-full',
              card:                 'bg-surface-2 border border-white/8 shadow-card-dark rounded-3xl backdrop-blur-xl',
              headerTitle:          'font-display font-bold text-white text-xl',
              headerSubtitle:       'text-white/40 text-sm',
              socialButtonsIconButton: 'border border-white/10 hover:border-violet-500/40 bg-white/4 hover:bg-white/8 transition-all rounded-xl',
              dividerLine:          'bg-white/8',
              dividerText:          'text-white/30 text-xs',
              formFieldLabel:       'text-white/60 text-xs font-medium uppercase tracking-wider',
              formFieldInput:       'bg-white/5 border border-white/10 text-white rounded-xl focus:border-violet-500/50 placeholder:text-white/20 text-sm',
              formButtonPrimary:    'bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 hover:opacity-90 transition-opacity rounded-xl font-semibold text-white text-sm py-3',
              footerActionLink:     'text-violet-400 hover:text-violet-300 font-medium',
              identityPreviewText:  'text-white/70',
              formFieldInputShowPasswordButton: 'text-white/40',
              otpCodeFieldInput:    'bg-white/5 border border-white/10 text-white rounded-xl',
              alertText:            'text-red-400 text-sm',
              internal:             'font-body',
            },
          }}
          redirectUrl="/dashboard"
          signUpUrl="/signup"
        />
      </div>
    </div>
  );
}
