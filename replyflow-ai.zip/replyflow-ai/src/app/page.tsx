'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  Zap, MessageSquare, TrendingUp, Shield, Users, Star,
  ChevronDown, ArrowRight, Check, X, Sparkles, BarChart3,
  Bot, Heart, Repeat2, Play, Instagram, Globe, Headphones,
  Menu, Moon, Bell, ChevronRight
} from 'lucide-react';
import { PLANS } from '@/lib/plans';

/* ─── Floating Orb ─────────────────────── */
const FloatingOrb = ({ className }: { className?: string }) => (
  <div className={`absolute rounded-full blur-3xl pointer-events-none ${className}`} />
);

/* ─── Fade-in Section ───────────────────── */
const FadeIn = ({
  children, delay = 0, className = '',
}: { children: React.ReactNode; delay?: number; className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: '-60px' }}
    transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

/* ─── Nav ───────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? 'py-3 glass border-b border-white/5' : 'py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center shadow-glow-sm">
            <Zap className="w-4 h-4 text-white" fill="white" />
          </div>
          <span className="font-display font-bold text-lg tracking-tight">
            Reply<span className="text-gradient">Flow</span> AI
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {[['Features', '#features'], ['Pricing', '#pricing'], ['Testimonials', '#testimonials'], ['FAQ', '#faq']].map(
            ([label, href]) => (
              <a key={label} href={href}
                className="px-4 py-2 text-sm text-white/60 hover:text-white rounded-lg hover:bg-white/5 transition-all font-medium"
              >
                {label}
              </a>
            )
          )}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/login" className="text-sm text-white/60 hover:text-white transition-colors font-medium px-4 py-2">
            Sign in
          </Link>
          <Link href="/signup" className="btn-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-glow-sm">
            Start Free Trial
          </Link>
        </div>

        {/* Mobile */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-white/5"
          >
            <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-2">
              {[['Features', '#features'], ['Pricing', '#pricing'], ['Testimonials', '#testimonials'], ['FAQ', '#faq']].map(
                ([label, href]) => (
                  <a key={label} href={href} onClick={() => setMobileOpen(false)}
                    className="py-2.5 px-3 text-white/70 hover:text-white text-sm font-medium rounded-lg hover:bg-white/5 transition-all"
                  >
                    {label}
                  </a>
                )
              )}
              <div className="flex gap-2 mt-2 pt-2 border-t border-white/5">
                <Link href="/login" className="flex-1 text-center py-2.5 rounded-xl glass text-sm font-medium">Sign in</Link>
                <Link href="/signup" className="flex-1 text-center py-2.5 rounded-xl btn-gradient text-sm font-semibold">Start Free Trial</Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

/* ─── Stats Ticker ──────────────────────── */
const STATS = [
  { label: 'Automations Sent', value: '12M+' },
  { label: 'Active Users', value: '8,400+' },
  { label: 'Instagram Accounts', value: '23K+' },
  { label: 'Leads Generated', value: '940K+' },
  { label: 'Uptime', value: '99.97%' },
];

/* ─── Hero ──────────────────────────────── */
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background orbs */}
      <FloatingOrb className="w-[600px] h-[600px] -top-32 -left-32 bg-purple-600/15 animate-glow-pulse" />
      <FloatingOrb className="w-[500px] h-[500px] -bottom-20 -right-20 bg-pink-500/10 animate-glow-pulse" style={{ animationDelay: '1.5s' } as React.CSSProperties} />
      <FloatingOrb className="w-[300px] h-[300px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-violet-500/8" />

      {/* Grid bg */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(124,58,237,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(124,58,237,0.04)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,black,transparent)]" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 pt-28 pb-16 text-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-sm mb-8 border border-violet-500/20"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-white/70">Official Meta Business Partner</span>
          <Instagram className="w-3.5 h-3.5 text-pink-400" />
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-5xl sm:text-6xl lg:text-[80px] font-bold leading-[1.05] tracking-tight mb-6"
        >
          Instagram on{' '}
          <span className="relative inline-block">
            <span className="text-gradient">Autopilot.</span>
            <svg className="absolute -bottom-2 left-0 w-full" height="6" viewBox="0 0 300 6">
              <path d="M0 3 Q75 0 150 3 Q225 6 300 3" stroke="url(#underline)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <defs>
                <linearGradient id="underline" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#7c3aed"/>
                  <stop offset="100%" stopColor="#ff2d78"/>
                </linearGradient>
              </defs>
            </svg>
          </span>
          <br />
          <span className="text-white/85">Grow on</span>{' '}
          <span className="text-gradient">Repeat.</span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="text-lg sm:text-xl text-white/55 max-w-2xl mx-auto mb-10 leading-relaxed font-body"
        >
          Auto-reply to comments, send DMs on keywords, capture leads, and
          grow followers — all without lifting a finger. Built for Indian creators & businesses.
        </motion.p>

        {/* CTA row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.35 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link
            href="/signup"
            className="group btn-gradient text-white font-semibold px-8 py-4 rounded-2xl text-base shadow-glow-md flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Start 7-Day Free Trial
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <button className="group flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm font-medium">
            <div className="w-10 h-10 rounded-full glass border border-white/10 flex items-center justify-center group-hover:border-violet-500/40 transition-all">
              <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
            </div>
            Watch 2-min demo
          </button>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 mt-10 text-sm text-white/35"
        >
          <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> No credit card required</span>
          <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> 7 days free, cancel anytime</span>
          <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> Setup in 2 minutes</span>
          <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> UPI / Razorpay payments</span>
        </motion.div>

        {/* Stats ticker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 flex flex-wrap items-center justify-center gap-x-10 gap-y-4"
        >
          {STATS.map((s, i) => (
            <div key={s.label} className="text-center">
              <div className="font-display text-2xl font-bold text-gradient">{s.value}</div>
              <div className="text-xs text-white/35 mt-0.5 font-medium">{s.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ─── Social Proof Logos ────────────────── */
const LOGOS = ['Swiggy', 'Zomato', 'Boat', 'Lenskart', 'Nykaa', 'Meesho', 'Zepto', 'Slice'];

function SocialProof() {
  return (
    <section className="py-10 border-y border-white/5 overflow-hidden">
      <div className="text-center mb-6 text-xs text-white/30 uppercase tracking-widest font-medium">
        Trusted by 8,000+ brands across India
      </div>
      <div className="relative flex overflow-hidden">
        <div className="flex gap-16 animate-marquee whitespace-nowrap items-center">
          {[...LOGOS, ...LOGOS].map((logo, i) => (
            <span key={i} className="font-display text-lg font-bold text-white/15 hover:text-white/30 transition-colors cursor-default">
              {logo}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Features ──────────────────────────── */
const FEATURES = [
  {
    icon: MessageSquare,
    color: '#7c3aed',
    title: 'Comment AutoDM',
    desc: 'Send automatic DMs to anyone who comments on your posts with custom keyword triggers.',
    stat: '10x more reach',
  },
  {
    icon: Bell,
    color: '#d946ef',
    title: 'Story Reply Bot',
    desc: 'Instantly reply to story reactions with personalized messages and capture leads.',
    stat: '3x more engagement',
  },
  {
    icon: Users,
    color: '#ff2d78',
    title: 'Welcome DM Flow',
    desc: 'Send automated welcome messages to new followers with your best offer.',
    stat: '45% conversion',
  },
  {
    icon: Bot,
    color: '#06b6d4',
    title: 'AI Reply Assistant',
    desc: 'Let AI craft personalized DM responses based on conversation context.',
    stat: '24/7 automation',
  },
  {
    icon: TrendingUp,
    color: '#10b981',
    title: 'Lead Capture',
    desc: 'Collect emails, phone numbers and names directly inside Instagram DMs.',
    stat: '8K+ leads/month',
  },
  {
    icon: BarChart3,
    color: '#f59e0b',
    title: 'Analytics & Insights',
    desc: 'Track DMs sent, open rates, lead conversions and follower growth in real time.',
    stat: 'Live dashboard',
  },
];

function FeaturesSection() {
  return (
    <section id="features" className="py-28 relative overflow-hidden">
      <FloatingOrb className="w-[400px] h-[400px] top-0 right-0 bg-violet-600/10" />
      <div className="max-w-7xl mx-auto px-4">
        <FadeIn className="text-center mb-16">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-violet-300 mb-5 border border-violet-500/20 font-medium uppercase tracking-wider">
            <Zap className="w-3 h-3" /> Automation Suite
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold leading-tight mb-4">
            Everything you need to<br />
            <span className="text-gradient">dominate Instagram</span>
          </h2>
          <p className="text-white/50 text-lg max-w-xl mx-auto">
            Replace hours of manual work with intelligent automation that runs 24/7.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <FadeIn key={f.title} delay={i * 0.07}>
              <div className="group relative glass rounded-2xl p-6 hover:border-white/10 transition-all duration-300 border border-white/5 overflow-hidden">
                {/* Hover glow */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                  style={{ background: `radial-gradient(ellipse at 30% 30%, ${f.color}15 0%, transparent 70%)` }}
                />

                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 relative"
                  style={{ background: `${f.color}18`, border: `1px solid ${f.color}30` }}
                >
                  <f.icon className="w-5 h-5" style={{ color: f.color }} />
                </div>

                <h3 className="font-display font-semibold text-lg text-white mb-2">{f.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed mb-4">{f.desc}</p>

                <div
                  className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full"
                  style={{ background: `${f.color}15`, color: f.color }}
                >
                  <TrendingUp className="w-3 h-3" /> {f.stat}
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Pricing Section ───────────────────── */
function PricingSection() {
  return (
    <section id="pricing" className="py-28 relative overflow-hidden">
      <FloatingOrb className="w-[500px] h-[500px] -bottom-20 left-1/4 bg-pink-500/10" />

      <div className="max-w-7xl mx-auto px-4">
        <FadeIn className="text-center mb-16">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-pink-300 mb-5 border border-pink-500/20 font-medium uppercase tracking-wider">
            <Star className="w-3 h-3" /> Pricing Plans
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold leading-tight mb-4">
            Simple, transparent pricing<br />
            <span className="text-gradient">for every business</span>
          </h2>
          <p className="text-white/50 text-lg max-w-xl mx-auto">
            Start free for 7 days. No credit card required. Cancel anytime.
          </p>
        </FadeIn>

        {/* Plans grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
          {PLANS.map((plan, i) => (
            <FadeIn key={plan.id} delay={i * 0.1}>
              <PlanCard plan={plan} />
            </FadeIn>
          ))}
        </div>

        {/* All plans include */}
        <FadeIn delay={0.3} className="mt-12 text-center">
          <p className="text-white/40 text-sm mb-4 font-medium">All plans include</p>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-2 text-sm text-white/60">
            {['7-day free trial', 'UPI & Razorpay payments', 'Auto-renew billing', '256-bit encryption', 'Cancel anytime', 'Email support'].map(f => (
              <span key={f} className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" /> {f}
              </span>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

function PlanCard({ plan }: { plan: typeof PLANS[0] }) {
  return (
    <div className={`relative rounded-3xl p-7 transition-all duration-300 plan-card ${
      plan.popular
        ? 'plan-popular'
        : 'glass border border-white/6'
    }`}>

      {/* Popular badge */}
      {plan.badge && (
        <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-10">
          <div
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold text-white whitespace-nowrap shadow-lg"
            style={{ background: `linear-gradient(135deg, ${plan.gradientFrom}, ${plan.gradientTo})` }}
          >
            <Star className="w-3 h-3 fill-white" />
            {plan.badge}
          </div>
        </div>
      )}

      {/* Plan header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: `${plan.gradientFrom}20`, border: `1px solid ${plan.gradientFrom}30` }}
          >
            <Zap className="w-4 h-4" style={{ color: plan.gradientFrom }} />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">{plan.name}</h3>
            <p className="text-xs text-white/40">{plan.instagramAccounts}</p>
          </div>
        </div>
        <p className="text-white/50 text-sm">{plan.tagline}</p>
      </div>

      {/* Price */}
      <div className="mb-6">
        <div className="flex items-end gap-1">
          <span className="font-display text-4xl font-bold text-white">{plan.priceDisplay}</span>
          <span className="text-white/40 text-sm mb-1.5 font-medium">{plan.period}</span>
        </div>
        <p className="text-xs text-white/35 mt-1">Billed monthly • Auto-renews</p>
      </div>

      {/* CTA */}
      <Link
        href={`/signup?plan=${plan.id}`}
        className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 mb-6 ${
          plan.popular
            ? 'btn-gradient text-white shadow-glow-sm'
            : 'border border-white/12 text-white hover:bg-white/5 hover:border-white/20'
        }`}
      >
        {plan.cta}
        <ArrowRight className="w-4 h-4" />
      </Link>

      {/* Divider */}
      <div className="h-px bg-white/6 mb-5" />

      {/* Features */}
      <ul className="space-y-3">
        {plan.features.map((feature) => (
          <li key={feature.text} className="flex items-start gap-3">
            {feature.included ? (
              <div
                className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: `${plan.gradientFrom}25`, border: `1px solid ${plan.gradientFrom}40` }}
              >
                <Check className="w-2.5 h-2.5" style={{ color: plan.gradientFrom }} />
              </div>
            ) : (
              <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 bg-white/5">
                <X className="w-2.5 h-2.5 text-white/20" />
              </div>
            )}
            <span className={`text-sm leading-relaxed ${
              feature.included
                ? feature.highlight
                  ? 'text-white font-medium'
                  : 'text-white/70'
                : 'text-white/25 line-through decoration-white/15'
            }`}>
              {feature.text}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ─── Testimonials ──────────────────────── */
const TESTIMONIALS = [
  {
    name: 'Priya Sharma',
    handle: '@priya.lifestyle',
    avatar: 'PS',
    color: '#d946ef',
    role: 'Lifestyle Creator · Mumbai',
    rating: 5,
    text: 'ReplyFlow completely changed my Instagram game. I was spending 3 hours daily replying to comments — now it\'s all automated. My DM response rate went from 20% to 95%!',
    metric: '+340% follower growth',
  },
  {
    name: 'Rahul Mehta',
    handle: '@rahul.eats',
    avatar: 'RM',
    color: '#7c3aed',
    role: 'Restaurant Owner · Delhi',
    rating: 5,
    text: 'We use the lead capture feature to collect customer enquiries from Instagram. Within the first month, we generated ₹2.4L in new revenue purely from automated DMs.',
    metric: '₹2.4L revenue in month 1',
  },
  {
    name: 'Kavya Reddy',
    handle: '@kavya.fitness',
    avatar: 'KR',
    color: '#ff2d78',
    role: 'Fitness Coach · Hyderabad',
    rating: 5,
    text: 'The AI reply feature is insane. It reads the context of every DM and responds like a real person. My students think I\'m always online, but it\'s just ReplyFlow!',
    metric: '200+ leads per week',
  },
  {
    name: 'Arjun Nair',
    handle: '@arjun.agency',
    avatar: 'AN',
    color: '#06b6d4',
    role: 'Marketing Agency · Bangalore',
    rating: 5,
    text: 'Managing 40+ client accounts was impossible before. The Agency plan lets us run everything from one dashboard. ROI is insane for the ₹2499 price point.',
    metric: '40 accounts managed',
  },
];

function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-28 relative overflow-hidden">
      <FloatingOrb className="w-[400px] h-[400px] top-0 left-0 bg-violet-600/10" />

      <div className="max-w-7xl mx-auto px-4">
        <FadeIn className="text-center mb-16">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-violet-300 mb-5 border border-violet-500/20 font-medium uppercase tracking-wider">
            <Heart className="w-3 h-3" fill="currentColor" /> Social Proof
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold leading-tight mb-4">
            Loved by <span className="text-gradient">8,000+ creators</span><br />
            across India
          </h2>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {TESTIMONIALS.map((t, i) => (
            <FadeIn key={t.name} delay={i * 0.08}>
              <div className="glass rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-300 group">
                {/* Stars */}
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                <p className="text-white/70 text-sm leading-relaxed mb-5 italic">
                  &ldquo;{t.text}&rdquo;
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                      style={{ background: `linear-gradient(135deg, ${t.color}, ${t.color}88)` }}
                    >
                      {t.avatar}
                    </div>
                    <div>
                      <div className="text-white text-sm font-semibold">{t.name}</div>
                      <div className="text-white/35 text-xs">{t.role}</div>
                    </div>
                  </div>
                  <div
                    className="text-xs font-semibold px-3 py-1 rounded-full"
                    style={{ background: `${t.color}15`, color: t.color }}
                  >
                    {t.metric}
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── FAQ ───────────────────────────────── */
const FAQS = [
  {
    q: 'Is ReplyFlow AI safe for my Instagram account?',
    a: 'Yes, completely. ReplyFlow uses the official Meta Business API — not any third-party scraping or bots. Your account is 100% safe from bans or restrictions. We\'re an official Meta Business Partner.',
  },
  {
    q: 'How does the 7-day free trial work?',
    a: 'Sign up and instantly access all features of the Pro plan free for 7 days. No credit card required to start. After 7 days, you\'ll be prompted to choose a plan. If you don\'t pay, automations pause but your data stays safe.',
  },
  {
    q: 'What payment methods do you support?',
    a: 'We support all major Indian payment methods: UPI (PhonePe, Google Pay, Paytm), Credit/Debit Cards, Net Banking, and Razorpay Checkout. Payments are processed securely via Razorpay with instant confirmation.',
  },
  {
    q: 'Can I connect multiple Instagram accounts?',
    a: 'Yes. Starter plan supports 1 account, Pro supports 5 accounts, and Agency plan supports unlimited accounts. You can switch between accounts seamlessly from the dashboard.',
  },
  {
    q: 'Can I cancel or change my plan anytime?',
    a: 'Absolutely. Cancel or change your plan anytime from the billing dashboard. No cancellation fees. If you cancel, you keep access until the end of your current billing period.',
  },
  {
    q: 'Does the AI really understand context?',
    a: 'Yes. The AI Reply Assistant uses GPT-4-class models fine-tuned for Instagram conversations. It understands the context of each DM thread and crafts responses that sound natural and human.',
  },
];

function FAQSection() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="py-28 relative">
      <div className="max-w-3xl mx-auto px-4">
        <FadeIn className="text-center mb-14">
          <h2 className="font-display text-4xl font-bold mb-4">
            Frequently asked <span className="text-gradient">questions</span>
          </h2>
          <p className="text-white/50">Everything you need to know before signing up.</p>
        </FadeIn>

        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <FadeIn key={i} delay={i * 0.05}>
              <div
                className={`glass rounded-2xl border transition-all duration-300 overflow-hidden ${
                  open === i ? 'border-violet-500/30' : 'border-white/5'
                }`}
              >
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-display font-semibold text-white/90 pr-4 text-sm sm:text-base">{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-white/40 flex-shrink-0 transition-transform duration-300 ${
                      open === i ? 'rotate-180 text-violet-400' : ''
                    }`}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: 'auto' }}
                      exit={{ height: 0 }}
                      transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 pb-5 text-sm text-white/50 leading-relaxed">{faq.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── CTA Banner ────────────────────────── */
function CTASection() {
  return (
    <section className="py-24 px-4">
      <FadeIn>
        <div className="max-w-4xl mx-auto relative overflow-hidden rounded-3xl">
          {/* BG */}
          <div className="absolute inset-0 bg-gradient-to-br from-violet-600/30 via-purple-500/20 to-pink-500/30" />
          <div className="absolute inset-0 glass" />
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-violet-600/20 rounded-full blur-3xl" />
          <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-pink-500/20 rounded-full blur-3xl" />

          <div className="relative z-10 text-center py-16 px-6">
            <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-1.5 text-sm mb-6 text-white/80">
              <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
              Limited Time: 7 Days Free
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-4">
              Ready to automate<br />your Instagram?
            </h2>
            <p className="text-white/60 text-lg mb-8 max-w-lg mx-auto">
              Join 8,000+ Indian creators and businesses growing on autopilot.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/signup"
                className="btn-gradient text-white font-bold px-10 py-4 rounded-2xl text-base shadow-glow-md flex items-center gap-2 group"
              >
                <Zap className="w-4 h-4" />
                Start Free Trial — No Card Needed
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
            <p className="text-white/35 text-xs mt-4">
              UPI • PhonePe • Google Pay • Razorpay — All Indian payments accepted
            </p>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}

/* ─── Footer ────────────────────────────── */
function Footer() {
  return (
    <footer className="border-t border-white/5 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          <div className="col-span-2">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center">
                <Zap className="w-3.5 h-3.5 text-white" fill="white" />
              </div>
              <span className="font-display font-bold text-base">
                Reply<span className="text-gradient">Flow</span> AI
              </span>
            </Link>
            <p className="text-white/35 text-sm leading-relaxed max-w-xs">
              Instagram automation platform built for Indian creators, businesses and agencies.
            </p>
          </div>

          {[
            { title: 'Product', links: ['Features', 'Pricing', 'Changelog', 'Status'] },
            { title: 'Company', links: ['About', 'Blog', 'Careers', 'Press'] },
            { title: 'Legal', links: ['Privacy', 'Terms', 'Refund Policy', 'Cookie Policy'] },
          ].map(col => (
            <div key={col.title}>
              <h4 className="text-white/70 text-sm font-semibold mb-3 font-display">{col.title}</h4>
              <ul className="space-y-2">
                {col.links.map(link => (
                  <li key={link}>
                    <a href="#" className="text-white/35 hover:text-white/70 text-sm transition-colors">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-sm">
            © 2025 ReplyFlow AI. Made with ❤️ in India.
          </p>
          <div className="flex items-center gap-4 text-white/25 text-xs">
            <span>UPI ID: 7673962811@ybl</span>
            <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> 256-bit SSL</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ─── Main Page ─────────────────────────── */
export default function HomePage() {
  return (
    <div className="min-h-screen mesh-gradient">
      <Navbar />
      <HeroSection />
      <SocialProof />
      <FeaturesSection />
      <PricingSection />
      <TestimonialsSection />
      <FAQSection />
      <CTASection />
      <Footer />
    </div>
  );
}
