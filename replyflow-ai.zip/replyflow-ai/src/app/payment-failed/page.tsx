// src/app/payment-failed/page.tsx
'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { XCircle, RefreshCw, ArrowLeft, Headphones } from 'lucide-react';

export default function PaymentFailedPage() {
  return (
    <div className="min-h-screen mesh-gradient flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md text-center"
      >
        {/* Error icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
          className="w-20 h-20 rounded-full bg-red-500/15 border border-red-500/35 flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(248,113,113,0.2)]"
        >
          <XCircle className="w-10 h-10 text-red-400" />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <h1 className="font-display text-3xl font-bold text-white mb-2">Payment Failed</h1>
          <p className="text-white/50 text-base mb-8">
            Don&apos;t worry — your account is safe and no money was deducted. Please try again.
          </p>
        </motion.div>

        {/* Reasons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-2xl p-5 border border-red-500/15 mb-6 text-left"
        >
          <div className="text-xs text-white/40 uppercase tracking-wider font-medium mb-3">Common reasons</div>
          <ul className="space-y-2 text-sm text-white/55">
            {[
              'UPI app timeout — please retry',
              'Insufficient balance in account',
              'Bank declined the transaction',
              'Network issue during payment',
            ].map(r => (
              <li key={r} className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400 flex-shrink-0" />
                {r}
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col gap-3"
        >
          <Link href="/pricing" className="btn-gradient text-white font-semibold py-3.5 rounded-xl text-sm flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4" /> Try Payment Again
          </Link>
          <Link href="/dashboard" className="py-3.5 rounded-xl glass border border-white/10 text-sm font-medium flex items-center justify-center gap-2 text-white/60 hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Link>
          <a href="mailto:support@replyflow.ai" className="py-3 text-xs text-white/30 hover:text-white/50 flex items-center justify-center gap-1.5 transition-colors">
            <Headphones className="w-3.5 h-3.5" /> Need help? Contact support
          </a>
        </motion.div>
      </motion.div>
    </div>
  );
}
