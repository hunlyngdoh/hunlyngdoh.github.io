'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check, X, Zap, Star, ArrowRight, Shield, Clock,
  Smartphone, CreditCard, Building2, QrCode, ChevronRight,
  Sparkles, TrendingUp, Users, BarChart3
} from 'lucide-react';
import { PLANS, PAYMENT_METHODS, type Plan, type PaymentMethodId } from '@/lib/plans';
import toast from 'react-hot-toast';

/* ─── Plan comparison table data ────────── */
const COMPARE_ROWS = [
  { label: 'Instagram Accounts',     starter: '1',         pro: '5',              agency: 'Unlimited' },
  { label: 'Auto DMs / Day',         starter: '500',       pro: '5,000',          agency: 'Unlimited' },
  { label: 'Comment AutoDM',         starter: true,        pro: true,             agency: true },
  { label: 'Story Reply',            starter: true,        pro: true,             agency: true },
  { label: 'Welcome DM',             starter: true,        pro: true,             agency: true },
  { label: 'Keyword Triggers',       starter: '5',         pro: 'Unlimited',      agency: 'Unlimited' },
  { label: 'AI Reply Assistant',     starter: false,       pro: true,             agency: true },
  { label: 'Lead Capture',           starter: false,       pro: true,             agency: true },
  { label: 'Analytics',              starter: 'Basic',     pro: 'Advanced',       agency: 'Full + Export' },
  { label: 'Team Members',           starter: '1',         pro: '3',              agency: 'Unlimited' },
  { label: 'API Access',             starter: false,       pro: false,            agency: true },
  { label: 'White-label',            starter: false,       pro: false,            agency: true },
  { label: 'Dedicated Manager',      starter: false,       pro: false,            agency: true },
  { label: 'Support',                starter: 'Email',     pro: 'Priority',       agency: 'SLA + Phone' },
];

/* ─── Payment Dialog ────────────────────── */
interface PaymentDialogProps {
  plan: Plan | null;
  onClose: () => void;
}

function PaymentDialog({ plan, onClose }: PaymentDialogProps) {
  const router = useRouter();
  const [method, setMethod] = useState<PaymentMethodId>('upi');
  const [loading, setLoading] = useState(false);
  const [upiId, setUpiId] = useState('');
  const [step, setStep] = useState<'method' | 'processing' | 'verify'>('method');

  if (!plan) return null;

  const handlePayment = async () => {
    setLoading(true);

    try {
      // Create Razorpay order
      const res = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId: plan.id, paymentMethod: method }),
      });
      const data = await res.json();

      if (!data.orderId) throw new Error(data.error || 'Failed to create order');

      // Load Razorpay SDK
      const razorpayKey = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;

      const options = {
        key: razorpayKey,
        amount: data.amount,
        currency: 'INR',
        name: 'ReplyFlow AI',
        description: `${plan.name} Plan - Monthly`,
        order_id: data.orderId,
        prefill: { contact: '', email: '' },
        theme: { color: '#7c3aed' },
        method: {
          upi: method === 'upi' || method === 'phonepe' || method === 'googlepay',
          card: method === 'card',
          netbanking: method === 'netbanking',
        },
        config: {
          display: {
            blocks: {
              utib: { name: 'UPI Apps', instruments: [{ method: 'upi' }] },
            },
            sequence: ['block.utib'],
            preferences: { show_default_blocks: method === 'card' || method === 'netbanking' },
          },
        },
        handler: async (response: any) => {
          // Verify payment
          const verify = await fetch('/api/razorpay/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              planId: plan.id,
            }),
          });
          const result = await verify.json();

          if (result.success) {
            router.push(`/payment-success?plan=${plan.id}&payment=${response.razorpay_payment_id}`);
          } else {
            router.push('/payment-failed');
          }
        },
        modal: {
          ondismiss: () => setLoading(false),
        },
      };

      // @ts-ignore
      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (err: any) {
      toast.error(err.message || 'Payment failed. Please try again.');
      setLoading(false);
    }
  };

  const methodIcons: Record<PaymentMethodId, React.ReactNode> = {
    upi: <QrCode className="w-5 h-5" />,
    phonepe: <Smartphone className="w-5 h-5" />,
    googlepay: <Smartphone className="w-5 h-5" />,
    card: <CreditCard className="w-5 h-5" />,
    netbanking: <Building2 className="w-5 h-5" />,
  };

  const methodColors: Record<PaymentMethodId, string> = {
    upi: '#5f259f',
    phonepe: '#5f259f',
    googlepay: '#4285f4',
    card: '#7c3aed',
    netbanking: '#059669',
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
        style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ y: 60, opacity: 0, scale: 0.97 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: 60, opacity: 0, scale: 0.97 }}
          transition={{ type: 'spring', damping: 28, stiffness: 300 }}
          className="w-full max-w-md glass-strong rounded-3xl overflow-hidden"
          style={{ border: '1px solid rgba(124,58,237,0.25)' }}
        >
          {/* Header */}
          <div className="p-6 border-b border-white/6">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-display font-bold text-xl">Complete Payment</h3>
              <button onClick={onClose} className="text-white/40 hover:text-white transition-colors text-xl leading-none">×</button>
            </div>
            <div className="flex items-center gap-3 mt-3">
              <div
                className="px-3 py-1.5 rounded-xl text-sm font-bold text-white"
                style={{ background: `linear-gradient(135deg, ${plan.gradientFrom}, ${plan.gradientTo})` }}
              >
                {plan.name}
              </div>
              <span className="text-white/60 text-sm">{plan.priceDisplay}/month</span>
              <span className="text-xs text-emerald-400 glass px-2 py-0.5 rounded-full border border-emerald-500/20">
                Auto-renew
              </span>
            </div>
          </div>

          {/* Payment methods */}
          <div className="p-6 space-y-3">
            <p className="text-white/50 text-xs uppercase tracking-wider font-medium mb-4">
              Choose payment method
            </p>

            {PAYMENT_METHODS.map((pm) => (
              <button
                key={pm.id}
                onClick={() => setMethod(pm.id as PaymentMethodId)}
                className={`payment-method-card w-full flex items-center gap-4 ${method === pm.id ? 'selected' : ''}`}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: method === pm.id ? `${methodColors[pm.id as PaymentMethodId]}20` : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${method === pm.id ? methodColors[pm.id as PaymentMethodId] + '40' : 'rgba(255,255,255,0.06)'}`,
                    color: method === pm.id ? methodColors[pm.id as PaymentMethodId] : 'rgba(255,255,255,0.5)',
                  }}
                >
                  {methodIcons[pm.id as PaymentMethodId]}
                </div>
                <div className="flex-1 text-left">
                  <div className="text-white text-sm font-medium flex items-center gap-2">
                    {pm.label}
                    {pm.popular && (
                      <span className="text-xs text-violet-300 bg-violet-500/15 px-2 py-0.5 rounded-full border border-violet-500/20">
                        Popular
                      </span>
                    )}
                  </div>
                  <div className="text-white/40 text-xs mt-0.5">{pm.description}</div>
                </div>
                <div
                  className={`w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all ${
                    method === pm.id
                      ? 'border-violet-500 bg-violet-500'
                      : 'border-white/20 bg-transparent'
                  }`}
                >
                  {method === pm.id && (
                    <div className="w-full h-full rounded-full flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-white" />
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* UPI QR info */}
          {(method === 'upi' || method === 'phonepe' || method === 'googlepay') && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="px-6 pb-2"
            >
              <div className="glass rounded-2xl p-4 border border-violet-500/15">
                <div className="flex items-center gap-2 text-xs text-violet-300 mb-2 font-medium">
                  <Shield className="w-3.5 h-3.5" />
                  Instant UPI payment · Secured by Razorpay
                </div>
                <div className="text-xs text-white/40">
                  UPI ID: <span className="text-white/70 font-mono">7673962811@ybl</span> will receive payment
                </div>
              </div>
            </motion.div>
          )}

          {/* Summary & Pay button */}
          <div className="p-6 border-t border-white/6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-white/50">{plan.name} Plan</span>
              <span className="text-white">{plan.priceDisplay}</span>
            </div>
            <div className="flex justify-between text-sm mb-4">
              <span className="text-white/50">GST (18%)</span>
              <span className="text-white">₹{Math.round(plan.price * 0.18)}</span>
            </div>
            <div className="flex justify-between font-semibold border-t border-white/6 pt-3 mb-5">
              <span>Total today</span>
              <span className="text-gradient text-lg">₹{Math.round(plan.price * 1.18)}</span>
            </div>

            <button
              onClick={handlePayment}
              disabled={loading}
              className="w-full btn-gradient text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 text-base shadow-glow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Pay ₹{Math.round(plan.price * 1.18)} & Activate
                </>
              )}
            </button>

            <div className="flex items-center justify-center gap-4 mt-4 text-xs text-white/25">
              <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> 256-bit SSL</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Cancel anytime</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

/* ─── Pricing Cards ─────────────────────── */
function PricingCard({ plan, onSelect }: { plan: Plan; onSelect: (plan: Plan) => void }) {
  const isPopular = plan.popular;

  return (
    <motion.div
      whileHover={{ y: isPopular ? -4 : -6 }}
      className={`relative rounded-3xl p-7 flex flex-col transition-all duration-300 ${
        isPopular
          ? 'plan-popular'
          : 'glass border border-white/6'
      }`}
    >
      {/* Badge */}
      {plan.badge && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <div
            className="flex items-center gap-1.5 px-5 py-1.5 rounded-full text-xs font-bold text-white shadow-glow-sm"
            style={{ background: `linear-gradient(135deg, ${plan.gradientFrom}, ${plan.gradientTo})` }}
          >
            <Star className="w-3 h-3 fill-white" />
            {plan.badge}
          </div>
        </div>
      )}

      {/* Plan header */}
      <div className="mb-5 mt-2">
        <div
          className="inline-flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full mb-4"
          style={{ background: `${plan.gradientFrom}18`, color: plan.gradientFrom, border: `1px solid ${plan.gradientFrom}25` }}
        >
          <Zap className="w-3 h-3" fill="currentColor" />
          {plan.name} Plan
        </div>
        <div className="flex items-baseline gap-1 mb-1.5">
          <span className="font-display text-5xl font-bold text-white">{plan.priceDisplay}</span>
          <span className="text-white/40 font-medium">/month</span>
        </div>
        <p className="text-white/40 text-sm">{plan.tagline}</p>
      </div>

      {/* CTA */}
      <button
        onClick={() => onSelect(plan)}
        className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 mb-6 group ${
          isPopular
            ? 'btn-gradient text-white shadow-glow-sm'
            : 'border border-white/12 text-white hover:bg-white/5 hover:border-white/20'
        }`}
      >
        <Sparkles className="w-4 h-4" />
        Start 7-Day Free Trial
        <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
      </button>

      {/* Divider */}
      <div className="h-px bg-gradient-to-r from-transparent via-white/8 to-transparent mb-5" />

      {/* Features */}
      <ul className="space-y-3 flex-1">
        {plan.features.slice(0, 9).map((feature) => (
          <li key={feature.text} className="flex items-start gap-3">
            {feature.included ? (
              <div
                className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: `${plan.gradientFrom}20`, border: `1px solid ${plan.gradientFrom}35` }}
              >
                <Check className="w-2.5 h-2.5" style={{ color: plan.gradientFrom }} />
              </div>
            ) : (
              <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 bg-white/5">
                <X className="w-2.5 h-2.5 text-white/20" />
              </div>
            )}
            <span className={`text-sm leading-snug ${
              !feature.included ? 'text-white/22 line-through decoration-white/12' :
              feature.highlight ? 'text-white font-medium' : 'text-white/65'
            }`}>
              {feature.text}
            </span>
          </li>
        ))}
      </ul>

      {/* Bottom info */}
      <div className="mt-5 pt-4 border-t border-white/5 text-center">
        <p className="text-xs text-white/30">
          Monthly billing · Auto-renews · Cancel anytime
        </p>
      </div>
    </motion.div>
  );
}

/* ─── Compare table ─────────────────────── */
function CompareTable() {
  const renderCell = (val: string | boolean) => {
    if (typeof val === 'boolean') {
      return val
        ? <Check className="w-4 h-4 text-emerald-400 mx-auto" />
        : <X className="w-4 h-4 text-white/20 mx-auto" />;
    }
    return <span className="text-sm text-white/70">{val}</span>;
  };

  return (
    <div className="mt-20 overflow-x-auto">
      <div className="text-center mb-8">
        <h3 className="font-display text-2xl font-bold text-white mb-2">Full Feature Comparison</h3>
        <p className="text-white/40 text-sm">See exactly what each plan includes</p>
      </div>
      <table className="w-full min-w-[600px]">
        <thead>
          <tr>
            <th className="text-left py-3 px-4 text-white/40 text-sm font-medium w-48">Feature</th>
            {PLANS.map(p => (
              <th key={p.id} className="text-center py-3 px-4">
                <span
                  className="text-sm font-bold px-3 py-1 rounded-full"
                  style={{ background: `${p.gradientFrom}18`, color: p.gradientFrom }}
                >
                  {p.name}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {COMPARE_ROWS.map((row, i) => (
            <tr
              key={row.label}
              className={`border-t ${i % 2 === 0 ? 'border-white/4 bg-white/[0.015]' : 'border-white/4'}`}
            >
              <td className="py-3 px-4 text-white/60 text-sm">{row.label}</td>
              <td className="py-3 px-4 text-center">{renderCell(row.starter)}</td>
              <td className="py-3 px-4 text-center">{renderCell(row.pro)}</td>
              <td className="py-3 px-4 text-center">{renderCell(row.agency)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ─── Main Page ─────────────────────────── */
export default function PricingPage() {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [showCompare, setShowCompare] = useState(false);

  // Load Razorpay SDK
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, []);

  return (
    <div className="min-h-screen mesh-gradient">
      {/* Nav */}
      <header className="fixed top-0 inset-x-0 z-40 glass border-b border-white/5 py-4 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-white" fill="white" />
            </div>
            <span className="font-display font-bold text-base">Reply<span className="text-gradient">Flow</span> AI</span>
          </Link>
          <Link href="/signup" className="btn-gradient text-white text-sm font-semibold px-4 py-2 rounded-xl">
            Start Free
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 pt-28 pb-20">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65 }}
          className="text-center mb-16"
        >
          {/* Trial badge */}
          <div className="inline-flex items-center gap-2 glass rounded-full px-5 py-2 text-sm mb-6 border border-emerald-500/25 text-emerald-300">
            <Clock className="w-4 h-4" />
            <span className="font-semibold">7-Day Free Trial</span>
            <span className="text-white/50">— No credit card required</span>
          </div>

          <h1 className="font-display text-5xl sm:text-6xl font-bold leading-tight mb-5">
            Choose your plan.<br />
            <span className="text-gradient">Start growing today.</span>
          </h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto mb-8">
            All plans start with a 7-day free trial. After trial, choose monthly billing.
            All Indian payment methods accepted.
          </p>

          {/* Payment methods display */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
            {[
              { label: 'UPI', emoji: '⚡', color: '#5f259f' },
              { label: 'PhonePe', emoji: '📱', color: '#5f259f' },
              { label: 'Google Pay', emoji: 'G', color: '#4285f4' },
              { label: 'Razorpay', emoji: 'R', color: '#3395ff' },
              { label: 'Cards', emoji: '💳', color: '#7c3aed' },
              { label: 'Net Banking', emoji: '🏦', color: '#059669' },
            ].map(pm => (
              <div
                key={pm.label}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium glass border border-white/6"
              >
                <span>{pm.emoji}</span>
                <span className="text-white/60">{pm.label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Plan cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
            >
              <PricingCard plan={plan} onSelect={setSelectedPlan} />
            </motion.div>
          ))}
        </div>

        {/* Guarantees */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          {[
            { icon: Shield,     label: '100% Secure',     sub: '256-bit SSL encryption' },
            { icon: Clock,      label: 'Cancel Anytime',  sub: 'No cancellation fees' },
            { icon: TrendingUp, label: 'Auto-Upgrade',    sub: 'Upgrade or downgrade freely' },
            { icon: Zap,        label: 'Instant Access',  sub: 'No waiting, start in 2 min' },
          ].map(g => (
            <div key={g.label} className="glass rounded-2xl p-4 border border-white/5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-violet-500/15 flex items-center justify-center flex-shrink-0">
                <g.icon className="w-4 h-4 text-violet-400" />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">{g.label}</div>
                <div className="text-xs text-white/40 mt-0.5">{g.sub}</div>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Compare toggle */}
        <div className="text-center mt-12">
          <button
            onClick={() => setShowCompare(!showCompare)}
            className="flex items-center gap-2 mx-auto text-sm text-white/50 hover:text-white transition-colors"
          >
            <span>{showCompare ? 'Hide' : 'Show'} full comparison table</span>
            <ChevronRight className={`w-4 h-4 transition-transform ${showCompare ? 'rotate-90' : ''}`} />
          </button>
        </div>

        {/* Comparison table */}
        <AnimatePresence>
          {showCompare && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.4 }}
              className="overflow-hidden"
            >
              <CompareTable />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Enterprise CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-16 glass rounded-3xl p-8 border border-white/6 flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div>
            <h3 className="font-display text-xl font-bold text-white mb-1">Need a custom plan?</h3>
            <p className="text-white/50 text-sm">Large team, special requirements, or want white-label? Talk to us.</p>
          </div>
          <a
            href="mailto:hello@replyflow.ai"
            className="flex-shrink-0 btn-gradient text-white font-semibold px-6 py-3 rounded-xl flex items-center gap-2"
          >
            Contact Sales <ArrowRight className="w-4 h-4" />
          </a>
        </motion.div>
      </div>

      {/* Payment Dialog */}
      {selectedPlan && (
        <PaymentDialog plan={selectedPlan} onClose={() => setSelectedPlan(null)} />
      )}
    </div>
  );
}
