// src/app/dashboard/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useUser } from '@clerk/nextjs';
import { motion } from 'framer-motion';
import {
  Zap, MessageSquare, TrendingUp, Users, BarChart3,
  ArrowUpRight, Plus, Instagram, Clock, ChevronRight,
  Activity, Bot, Heart, Repeat2, Star, AlertTriangle,
  CheckCircle2, Play, Pause
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { formatDistanceToNow, format } from 'date-fns';

/* ─── Fade In ───────────────────────────── */
const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

/* ─── Stat Card ─────────────────────────── */
function StatCard({
  label, value, icon: Icon, color, change, suffix = '', delay = 0,
}: {
  label: string; value: string | number; icon: any;
  color: string; change?: string; suffix?: string; delay?: number;
}) {
  return (
    <FI delay={delay}>
      <div className="glass rounded-2xl p-5 border border-white/5 hover:border-white/10 transition-all duration-300 group relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
          style={{ background: `radial-gradient(ellipse at 20% 20%, ${color}12 0%, transparent 60%)` }}
        />
        <div className="flex items-start justify-between mb-3 relative">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: `${color}18`, border: `1px solid ${color}28` }}
          >
            <Icon className="w-4 h-4" style={{ color }} />
          </div>
          {change && (
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" />{change}
            </span>
          )}
        </div>
        <div className="font-display text-2xl font-bold text-white mb-0.5 stat-number">
          {value}{suffix}
        </div>
        <div className="text-xs text-white/40 font-medium">{label}</div>
      </div>
    </FI>
  );
}

/* ─── Custom Tooltip ────────────────────── */
const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass rounded-xl px-3 py-2 border border-white/10 text-xs">
      <div className="text-white/50 mb-1">{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-white/70">{p.name}:</span>
          <span className="text-white font-semibold">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

/* ─── Automation Row ─────────────────────── */
function AutomationRow({ flow, onToggle }: { flow: any; onToggle: (id: string) => void }) {
  const typeColors: Record<string, string> = {
    COMMENT_AUTO_DM: '#7c3aed',
    STORY_REPLY:     '#d946ef',
    WELCOME_DM:      '#06b6d4',
    KEYWORD_TRIGGER: '#f59e0b',
    LEAD_CAPTURE:    '#10b981',
    AI_REPLY:        '#ff2d78',
  };
  const typeLabels: Record<string, string> = {
    COMMENT_AUTO_DM: 'Comment AutoDM',
    STORY_REPLY:     'Story Reply',
    WELCOME_DM:      'Welcome DM',
    KEYWORD_TRIGGER: 'Keyword Trigger',
    LEAD_CAPTURE:    'Lead Capture',
    AI_REPLY:        'AI Reply',
  };

  const color = typeColors[flow.type] || '#7c3aed';

  return (
    <div className="flex items-center gap-4 py-3 border-b border-white/4 last:border-0 group">
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}18`, border: `1px solid ${color}25` }}
      >
        <Zap className="w-3.5 h-3.5" style={{ color }} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-white truncate">{flow.name}</div>
        <div className="text-xs text-white/35 mt-0.5">{typeLabels[flow.type]} · {flow.totalTriggered} triggers</div>
      </div>

      <div className="text-xs text-white/40 hidden sm:block">{flow.totalReplied} sent</div>

      {/* Toggle */}
      <button
        onClick={() => onToggle(flow.id)}
        className={`relative w-10 h-5 rounded-full transition-all duration-300 flex-shrink-0 ${
          flow.isActive ? 'bg-violet-600' : 'bg-white/10'
        }`}
      >
        <span
          className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${
            flow.isActive ? 'left-5' : 'left-0.5'
          }`}
        />
      </button>
    </div>
  );
}

/* ─── Main Page ─────────────────────────── */
export default function DashboardPage() {
  const { user } = useUser();
  const [stats, setStats] = useState<any>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const [automations, setAutomations] = useState<any[]>([]);
  const [trialData, setTrialData] = useState<any>(null);
  const [igAccount, setIgAccount] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/analytics/stats').then(r => r.json()),
      fetch('/api/analytics/chart').then(r => r.json()),
      fetch('/api/automations').then(r => r.json()),
      fetch('/api/trial').then(r => r.json()),
      fetch('/api/users/instagram').then(r => r.json()),
    ]).then(([s, c, a, t, ig]) => {
      setStats(s);
      setChartData(c.data || MOCK_CHART);
      setAutomations(a.flows || []);
      setTrialData(t);
      setIgAccount(ig.account);
      setLoading(false);
    }).catch(() => {
      setChartData(MOCK_CHART);
      setLoading(false);
    });
  }, []);

  const handleToggleFlow = async (id: string) => {
    setAutomations(prev =>
      prev.map(f => f.id === id ? { ...f, isActive: !f.isActive } : f)
    );
    await fetch(`/api/automations/${id}/toggle`, { method: 'PATCH' });
  };

  const firstName = user?.firstName || 'there';
  const hour      = new Date().getHours();
  const greeting  = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  const statCards = [
    { label: 'DMs Sent Today',      value: stats?.dmsSentToday   ?? '—', icon: MessageSquare, color: '#7c3aed', change: '+12%' },
    { label: 'Comment Replies',     value: stats?.commentReplies ?? '—', icon: Repeat2,       color: '#d946ef', change: '+8%'  },
    { label: 'Leads Captured',      value: stats?.leadsTotal     ?? '—', icon: TrendingUp,    color: '#10b981', change: '+24%' },
    { label: 'Active Automations',  value: stats?.activeFlows    ?? '—', icon: Zap,           color: '#f59e0b'               },
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6">

      {/* Header */}
      <FI>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-white">
              {greeting}, {firstName} 👋
            </h2>
            <p className="text-white/40 text-sm mt-0.5">
              {format(new Date(), 'EEEE, MMMM d')} · Here&apos;s your automation summary
            </p>
          </div>

          <div className="flex items-center gap-3">
            {!igAccount && (
              <Link
                href="/dashboard/settings"
                className="flex items-center gap-2 px-4 py-2 rounded-xl glass border border-orange-500/25 text-orange-300 text-sm font-medium hover:border-orange-500/40 transition-all"
              >
                <Instagram className="w-4 h-4" />
                Connect Instagram
              </Link>
            )}
            <Link
              href="/dashboard/automations"
              className="btn-gradient text-white text-sm font-semibold px-4 py-2 rounded-xl flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              New Automation
            </Link>
          </div>
        </div>
      </FI>

      {/* Trial expired banner */}
      {trialData?.trialExpired && (
        <FI>
          <div className="rounded-2xl p-4 border border-red-500/30 bg-red-500/8 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <div>
                <div className="text-sm font-bold text-red-300">Your free trial has expired</div>
                <div className="text-xs text-white/40 mt-0.5">All automations are paused. Subscribe to reactivate instantly.</div>
              </div>
            </div>
            <Link href="/pricing" className="flex-shrink-0 btn-gradient text-white text-sm font-bold px-5 py-2.5 rounded-xl">
              Choose a Plan
            </Link>
          </div>
        </FI>
      )}

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s, i) => (
          <StatCard key={s.label} {...s} delay={i * 0.07} />
        ))}
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Chart */}
        <FI delay={0.2} className="lg:col-span-2">
          <div className="glass rounded-2xl p-5 border border-white/5 h-full">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-display font-semibold text-white">DM Activity</h3>
                <p className="text-xs text-white/35 mt-0.5">Last 7 days · All automations</p>
              </div>
              <div className="flex items-center gap-3 text-xs text-white/40">
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-violet-500" />DMs Sent</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-pink-500" />Leads</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={chartData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="dmGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#7c3aed" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#7c3aed" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="leadGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#ff2d78" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ff2d78" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="dms"   name="DMs Sent" stroke="#7c3aed" strokeWidth={2} fill="url(#dmGrad)"   dot={false} />
                <Area type="monotone" dataKey="leads" name="Leads"    stroke="#ff2d78" strokeWidth={2} fill="url(#leadGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </FI>

        {/* Quick stats / Instagram status */}
        <FI delay={0.25}>
          <div className="space-y-4">
            {/* Instagram account */}
            <div className="glass rounded-2xl p-4 border border-white/5">
              <div className="flex items-center gap-2 mb-3">
                <Instagram className="w-4 h-4 text-pink-400" />
                <span className="text-sm font-semibold text-white">Instagram Account</span>
              </div>
              {igAccount ? (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center text-white font-bold text-sm">
                    {igAccount.username?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">@{igAccount.username}</div>
                    <div className="text-xs text-emerald-400 flex items-center gap-1 mt-0.5">
                      <CheckCircle2 className="w-3 h-3" /> Connected
                    </div>
                  </div>
                </div>
              ) : (
                <Link href="/dashboard/settings" className="flex items-center justify-between p-3 rounded-xl border border-dashed border-white/15 hover:border-violet-500/30 transition-all group">
                  <span className="text-xs text-white/40 group-hover:text-white/60">Connect Instagram account</span>
                  <ChevronRight className="w-3.5 h-3.5 text-white/25 group-hover:text-violet-400" />
                </Link>
              )}
            </div>

            {/* Quick actions */}
            <div className="glass rounded-2xl p-4 border border-white/5">
              <div className="text-sm font-semibold text-white mb-3">Quick Actions</div>
              <div className="space-y-2">
                {[
                  { label: 'Create Comment AutoDM',  href: '/dashboard/automations?type=comment', color: '#7c3aed' },
                  { label: 'Set Up Welcome DM',       href: '/dashboard/automations?type=welcome', color: '#d946ef' },
                  { label: 'View Analytics Report',   href: '/dashboard/analytics',               color: '#10b981' },
                  { label: 'Manage Billing',           href: '/dashboard/billing',                 color: '#f59e0b' },
                ].map(action => (
                  <Link
                    key={action.label}
                    href={action.href}
                    className="flex items-center justify-between py-2 px-3 rounded-xl hover:bg-white/4 transition-all group"
                  >
                    <span className="text-xs text-white/55 group-hover:text-white/80">{action.label}</span>
                    <ChevronRight className="w-3 h-3 text-white/20 group-hover:text-white/50" style={{ color: action.color }} />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </FI>
      </div>

      {/* Automations list */}
      <FI delay={0.3}>
        <div className="glass rounded-2xl border border-white/5 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
            <div>
              <h3 className="font-display font-semibold text-white text-sm">Active Automations</h3>
              <p className="text-xs text-white/35 mt-0.5">{automations.filter(a => a.isActive).length} running</p>
            </div>
            <Link href="/dashboard/automations" className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 font-medium">
              View all <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="px-5">
            {automations.length === 0 ? (
              <div className="py-10 text-center">
                <Zap className="w-8 h-8 text-white/15 mx-auto mb-3" />
                <p className="text-sm text-white/30">No automations yet</p>
                <Link href="/dashboard/automations" className="inline-flex items-center gap-1.5 mt-3 text-xs text-violet-400 hover:text-violet-300 font-medium">
                  <Plus className="w-3 h-3" /> Create your first automation
                </Link>
              </div>
            ) : (
              automations.slice(0, 5).map(flow => (
                <AutomationRow key={flow.id} flow={flow} onToggle={handleToggleFlow} />
              ))
            )}
          </div>
        </div>
      </FI>
    </div>
  );
}

/* ─── Mock Chart Data (fallback) ─────────── */
const MOCK_CHART = [
  { date: 'Mon', dms: 120, leads: 18 },
  { date: 'Tue', dms: 245, leads: 32 },
  { date: 'Wed', dms: 189, leads: 27 },
  { date: 'Thu', dms: 312, leads: 45 },
  { date: 'Fri', dms: 276, leads: 38 },
  { date: 'Sat', dms: 198, leads: 29 },
  { date: 'Sun', dms: 345, leads: 52 },
];
