// src/app/dashboard/layout.tsx
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { UserButton, useUser } from '@clerk/nextjs';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Zap, BarChart3, CreditCard, Settings,
  HelpCircle, Bell, ChevronLeft, ChevronRight, Instagram,
  Users, Menu, X, Bot, TrendingUp, LogOut, Star, Clock,
  AlertTriangle, Crown
} from 'lucide-react';
import { useTrialStore } from '@/hooks/use-trial';
import { formatDistanceToNow } from 'date-fns';

const NAV_ITEMS = [
  { href: '/dashboard',             label: 'Overview',     icon: LayoutDashboard },
  { href: '/dashboard/automations', label: 'Automations',  icon: Zap },
  { href: '/dashboard/analytics',   label: 'Analytics',    icon: BarChart3 },
  { href: '/dashboard/billing',     label: 'Billing',      icon: CreditCard },
  { href: '/dashboard/settings',    label: 'Settings',     icon: Settings },
  { href: '/dashboard/help',        label: 'Help Center',  icon: HelpCircle },
];

function TrialBanner({ daysLeft }: { daysLeft: number }) {
  const router = useRouter();
  const isUrgent = daysLeft <= 2;

  return (
    <div
      className={`mx-3 mb-3 rounded-2xl p-3 border ${
        isUrgent
          ? 'bg-red-500/10 border-red-500/25'
          : 'bg-amber-500/10 border-amber-500/25'
      }`}
    >
      <div className="flex items-center gap-2 mb-2">
        {isUrgent
          ? <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
          : <Clock className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        }
        <span className={`text-xs font-bold ${isUrgent ? 'text-red-400' : 'text-amber-400'}`}>
          {daysLeft === 0 ? 'Trial expires today!' : `${daysLeft}d left in trial`}
        </span>
      </div>

      {/* Progress bar */}
      <div className="w-full h-1 bg-white/10 rounded-full mb-2.5 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${isUrgent ? 'bg-red-400' : 'bg-amber-400'}`}
          style={{ width: `${(daysLeft / 7) * 100}%` }}
        />
      </div>

      <button
        onClick={() => router.push('/pricing')}
        className="w-full text-center text-xs font-semibold py-1.5 rounded-xl btn-gradient text-white"
      >
        Upgrade Now →
      </button>
    </div>
  );
}

function ExpiredBanner() {
  const router = useRouter();
  return (
    <div className="mx-3 mb-3 rounded-2xl p-3 border bg-red-500/10 border-red-500/30">
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
        <span className="text-xs font-bold text-red-400">Trial Expired</span>
      </div>
      <p className="text-xs text-white/50 mb-2">Automations paused. Subscribe to reactivate.</p>
      <button
        onClick={() => router.push('/pricing')}
        className="w-full text-center text-xs font-bold py-2 rounded-xl bg-red-500/20 border border-red-500/40 text-red-300 hover:bg-red-500/30 transition-all"
      >
        Choose a Plan
      </button>
    </div>
  );
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname   = usePathname();
  const { user }   = useUser();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [trialData, setTrialData] = useState<any>(null);

  useEffect(() => {
    fetch('/api/trial').then(r => r.json()).then(setTrialData).catch(() => {});
    fetch('/api/users/notifications').then(r => r.json()).then(d => setNotifications(d.notifications || [])).catch(() => {});
  }, []);

  const showTrialBanner  = trialData?.trialActive && trialData?.daysRemaining !== undefined;
  const showExpiredBanner = trialData?.trialExpired;
  const unread = notifications.filter(n => !n.isRead).length;

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={`flex items-center gap-2.5 px-4 py-5 ${collapsed ? 'justify-center' : ''}`}>
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center flex-shrink-0 shadow-glow-sm">
          <Zap className="w-4 h-4 text-white" fill="white" />
        </div>
        {!collapsed && (
          <span className="font-display font-bold text-base">
            Reply<span className="text-gradient">Flow</span>
          </span>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 space-y-1 overflow-y-auto no-scrollbar">
        {NAV_ITEMS.map(item => {
          const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`sidebar-item ${active ? 'active' : ''} ${collapsed ? 'justify-center px-2' : ''}`}
              title={collapsed ? item.label : ''}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Trial / Expired banners */}
      {!collapsed && showExpiredBanner && <ExpiredBanner />}
      {!collapsed && showTrialBanner && !showExpiredBanner && (
        <TrialBanner daysLeft={trialData.daysRemaining} />
      )}

      {/* User */}
      <div className={`p-3 border-t border-white/5 flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>
        <UserButton
          afterSignOutUrl="/"
          appearance={{ elements: { avatarBox: 'w-8 h-8 rounded-xl' } }}
        />
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-white truncate">
              {user?.fullName || user?.firstName || 'User'}
            </div>
            <div className="text-xs text-white/35 truncate">
              {user?.primaryEmailAddress?.emailAddress}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-surface-0 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col flex-shrink-0 transition-all duration-300 border-r border-white/5 relative ${
          collapsed ? 'w-16' : 'w-60'
        }`}
        style={{ background: '#0a0a14' }}
      >
        <SidebarContent />

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-6 w-6 h-6 rounded-full glass border border-white/10 flex items-center justify-center text-white/40 hover:text-white transition-all hover:border-violet-500/30 z-10"
        >
          {collapsed
            ? <ChevronRight className="w-3 h-3" />
            : <ChevronLeft className="w-3 h-3" />}
        </button>
      </aside>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 w-64 z-50 lg:hidden border-r border-white/5"
              style={{ background: '#0a0a14' }}
            >
              <div className="absolute top-4 right-4">
                <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-lg hover:bg-white/5 text-white/50">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex-shrink-0 h-14 flex items-center justify-between px-4 border-b border-white/5" style={{ background: '#0a0a14' }}>
          <div className="flex items-center gap-3">
            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-1.5 rounded-lg hover:bg-white/5 text-white/50"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Page title */}
            <div>
              <h1 className="font-display font-bold text-white text-base leading-tight">
                {NAV_ITEMS.find(n => n.href === pathname)?.label ||
                 NAV_ITEMS.find(n => pathname.startsWith(n.href) && n.href !== '/dashboard')?.label ||
                 'Dashboard'}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Trial badge */}
            {showTrialBanner && !showExpiredBanner && (
              <Link href="/pricing" className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl badge-trial text-xs font-medium">
                <Clock className="w-3 h-3" />
                {trialData.daysRemaining}d trial left
              </Link>
            )}

            {showExpiredBanner && (
              <Link href="/pricing" className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl badge-expired text-xs font-bold animate-pulse">
                <AlertTriangle className="w-3 h-3" />
                Upgrade Now
              </Link>
            )}

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="relative p-2 rounded-xl hover:bg-white/5 text-white/50 hover:text-white transition-all"
              >
                <Bell className="w-4 h-4" />
                {unread > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-pink-500 flex items-center justify-center text-white text-[9px] font-bold">
                    {unread > 9 ? '9+' : unread}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {notifOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 top-full mt-2 w-80 glass-strong rounded-2xl border border-white/8 overflow-hidden shadow-card-dark z-50"
                  >
                    <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
                      <span className="font-semibold text-sm">Notifications</span>
                      <span className="text-xs text-violet-400">{unread} new</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto no-scrollbar">
                      {notifications.length === 0 ? (
                        <div className="py-8 text-center text-white/30 text-sm">No notifications</div>
                      ) : (
                        notifications.slice(0, 8).map(n => (
                          <div key={n.id} className={`px-4 py-3 border-b border-white/4 hover:bg-white/3 transition-colors ${!n.isRead ? 'bg-violet-500/5' : ''}`}>
                            <div className="text-sm font-medium text-white/90">{n.title}</div>
                            <div className="text-xs text-white/40 mt-0.5">{n.message}</div>
                            <div className="text-xs text-white/25 mt-1">
                              {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
