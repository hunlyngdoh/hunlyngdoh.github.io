// src/app/dashboard/help/page.tsx
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, ChevronDown, MessageSquare, BookOpen,
  Video, Mail, Zap, Bot, CreditCard, Instagram,
  ExternalLink, ArrowRight, LifeBuoy
} from 'lucide-react';

const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className={className}
  >
    {children}
  </motion.div>
);

const CATEGORIES = [
  {
    icon: Zap,       color: '#7c3aed', label: 'Automations',
    items: [
      { q: 'How do I create a Comment AutoDM?',
        a: 'Go to Automations → New Automation → Select "Comment AutoDM". Set your trigger keywords (e.g. "price, info, buy") and write your reply message. Enable it and connect your Instagram. The automation activates within 60 seconds.' },
      { q: 'What are keyword triggers?',
        a: 'Keyword triggers are words or phrases that, when commented on your post, automatically fire a DM to that person. Example: if someone comments "price", ReplyFlow instantly sends them your pricing info via DM.' },
      { q: 'How many automations can I create?',
        a: 'Starter plan: up to 10 automations. Pro plan: up to 50. Agency plan: unlimited. Each automation runs independently with its own keywords and reply message.' },
      { q: 'Can I add a delay to my DM replies?',
        a: 'Yes! When creating or editing an automation, use the delay slider to set a response delay of 0–300 seconds (5 minutes). A slight delay makes automations feel more human.' },
    ],
  },
  {
    icon: Instagram,  color: '#d946ef', label: 'Instagram',
    items: [
      { q: 'Do I need an Instagram Business account?',
        a: 'Yes. ReplyFlow uses the official Meta Graph API which requires either an Instagram Business or Creator account linked to a Facebook Page. Personal accounts are not supported by Meta\'s API.' },
      { q: 'Will my account get banned?',
        a: 'No. ReplyFlow only uses the official Meta Business API — the same API used by large brands. We never use bots, scrapers, or unofficial methods. Your account is 100% safe.' },
      { q: 'How do I connect my Instagram account?',
        a: 'Go to Settings → Instagram Account → Click "Connect Instagram Account". You\'ll be redirected to Facebook to authorize permissions. After approving, your account connects in seconds.' },
      { q: 'Can I connect multiple Instagram accounts?',
        a: 'Yes. Starter supports 1 account, Pro supports 5, and Agency supports unlimited accounts. Switch between accounts easily from the Settings page.' },
    ],
  },
  {
    icon: CreditCard, color: '#10b981', label: 'Billing & Payments',
    items: [
      { q: 'How does the free trial work?',
        a: 'You get 7 days of full Pro access — no credit card required. After 7 days, you\'ll receive an email and in-app prompt to choose a plan. If you don\'t subscribe, automations pause but your data is never deleted.' },
      { q: 'What payment methods are supported?',
        a: 'We support all Indian payment methods: UPI (PhonePe, Google Pay, Paytm, BHIM), Credit/Debit Cards (Visa, Mastercard, RuPay), Net Banking (all major banks), and Wallets via Razorpay checkout.' },
      { q: 'How do I upgrade or downgrade my plan?',
        a: 'Go to Dashboard → Billing → Change Plan. Select your new plan and complete payment. Upgrades activate instantly. Downgrades take effect at the end of your current billing period.' },
      { q: 'Can I get a refund?',
        a: 'We offer a 7-day money-back guarantee if you\'re not satisfied. Contact support@replyflow.ai within 7 days of payment with your payment ID. Refunds are processed within 5–7 business days.' },
    ],
  },
  {
    icon: Bot,        color: '#ff2d78', label: 'AI Features',
    items: [
      { q: 'How does the AI Reply Assistant work?',
        a: 'The AI reads the full context of each DM conversation and generates a personalized reply using a GPT-4-class model fine-tuned for Instagram. It sounds natural and maintains your brand voice.' },
      { q: 'Can I customize AI reply tone?',
        a: 'Yes. In the automation settings, you can set a "brand tone" — options include Professional, Friendly, Casual, and Excited. You can also provide a custom tone description.' },
      { q: 'Is the AI reply available on all plans?',
        a: 'AI Reply Assistant is available on Pro and Agency plans. Starter plan users can upgrade to unlock this feature.' },
    ],
  },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className={`border rounded-xl overflow-hidden transition-all duration-200 ${open ? 'border-violet-500/25' : 'border-white/5'}`}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3.5 text-left gap-3"
      >
        <span className="text-sm font-medium text-white/85 leading-snug">{q}</span>
        <ChevronDown
          className={`w-4 h-4 text-white/30 flex-shrink-0 transition-transform duration-300 ${open ? 'rotate-180 text-violet-400' : ''}`}
        />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
            className="overflow-hidden"
          >
            <p className="px-4 pb-4 text-sm text-white/50 leading-relaxed">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function HelpPage() {
  const [search, setSearch]       = useState('');
  const [activeCategory, setActiveCategory] = useState('Automations');

  const category = CATEGORIES.find(c => c.label === activeCategory) || CATEGORIES[0];
  const filtered = search
    ? CATEGORIES.flatMap(c => c.items.filter(
        i => i.q.toLowerCase().includes(search.toLowerCase()) ||
             i.a.toLowerCase().includes(search.toLowerCase())
      ))
    : category.items;

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-3xl">

      <FI>
        <h2 className="font-display text-xl font-bold text-white">Help Center</h2>
        <p className="text-white/40 text-sm mt-0.5">Find answers or reach our support team</p>
      </FI>

      {/* Search */}
      <FI delay={0.05}>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search help articles..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl pl-11 pr-5 py-3.5 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/40 transition-colors"
          />
        </div>
      </FI>

      {/* Support tiles */}
      <FI delay={0.1}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { icon: MessageSquare, label: 'Live Chat',   desc: 'Chat with us',      color: '#7c3aed', action: () => {} },
            { icon: Mail,          label: 'Email',        desc: 'support@replyflow.ai', color: '#d946ef', action: () => window.open('mailto:support@replyflow.ai') },
            { icon: Video,         label: 'Video Guides', desc: 'Watch tutorials',  color: '#10b981', action: () => {} },
            { icon: BookOpen,      label: 'Docs',         desc: 'Full docs',        color: '#f59e0b', action: () => {} },
          ].map(s => (
            <button
              key={s.label}
              onClick={s.action}
              className="glass rounded-2xl p-4 border border-white/5 hover:border-white/12 text-left transition-all group"
            >
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center mb-3"
                style={{ background: `${s.color}18`, border: `1px solid ${s.color}25` }}
              >
                <s.icon className="w-4 h-4" style={{ color: s.color }} />
              </div>
              <div className="text-sm font-semibold text-white group-hover:text-white transition-colors">{s.label}</div>
              <div className="text-xs text-white/35 mt-0.5">{s.desc}</div>
            </button>
          ))}
        </div>
      </FI>

      {!search && (
        /* Category tabs */
        <FI delay={0.15}>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {CATEGORIES.map(cat => (
              <button
                key={cat.label}
                onClick={() => setActiveCategory(cat.label)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${
                  activeCategory === cat.label
                    ? 'bg-violet-600 text-white'
                    : 'glass border border-white/8 text-white/50 hover:text-white'
                }`}
              >
                <cat.icon className="w-3.5 h-3.5" />
                {cat.label}
              </button>
            ))}
          </div>
        </FI>
      )}

      {/* FAQ items */}
      <FI delay={0.2}>
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-white/30">
              <LifeBuoy className="w-8 h-8 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No results for &ldquo;{search}&rdquo;</p>
              <p className="text-xs mt-1">Try different keywords or contact support</p>
            </div>
          ) : (
            filtered.map((item, i) => <FAQItem key={i} q={item.q} a={item.a} />)
          )}
        </div>
      </FI>

      {/* Contact support CTA */}
      <FI delay={0.25}>
        <div className="glass rounded-2xl p-5 border border-white/5 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-violet-500/15 flex items-center justify-center flex-shrink-0">
            <LifeBuoy className="w-5 h-5 text-violet-400" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-white text-sm">Still need help?</div>
            <div className="text-xs text-white/40 mt-0.5">Our team replies within 4 hours on business days</div>
          </div>
          <a
            href="mailto:support@replyflow.ai"
            className="btn-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-xl flex items-center gap-2 flex-shrink-0"
          >
            <Mail className="w-4 h-4" /> Contact Support
          </a>
        </div>
      </FI>
    </div>
  );
}
