// src/app/dashboard/settings/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { useUser } from '@clerk/nextjs';
import { motion } from 'framer-motion';
import {
  Instagram, User, Bell, Shield, Key, Save,
  CheckCircle2, AlertCircle, Unlink, ExternalLink,
  Smartphone, Mail, Globe, Lock
} from 'lucide-react';
import toast from 'react-hot-toast';

const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className={className}
  >
    {children}
  </motion.div>
);

function Section({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl border border-white/5 overflow-hidden">
      <div className="px-5 py-4 border-b border-white/5">
        <h3 className="font-display font-semibold text-white text-sm">{title}</h3>
        <p className="text-white/40 text-xs mt-0.5">{desc}</p>
      </div>
      <div className="p-5 space-y-4">{children}</div>
    </div>
  );
}

function Toggle({
  label, desc, checked, onChange,
}: { label: string; desc: string; checked: boolean; onChange: () => void }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <div className="text-sm font-medium text-white">{label}</div>
        <div className="text-xs text-white/40 mt-0.5">{desc}</div>
      </div>
      <button
        onClick={onChange}
        className={`relative w-11 h-6 rounded-full transition-all duration-300 flex-shrink-0 ${
          checked ? 'bg-violet-600' : 'bg-white/10'
        }`}
      >
        <span
          className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${
            checked ? 'left-6' : 'left-1'
          }`}
        />
      </button>
    </div>
  );
}

export default function SettingsPage() {
  const { user } = useUser();
  const [igAccount, setIgAccount] = useState<any>(null);
  const [notifs, setNotifs] = useState({
    emailTrialReminder:    true,
    emailPaymentReceipt:   true,
    emailWeeklySummary:    true,
    pushNewLead:           true,
    pushDmMilestone:       false,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/users/instagram')
      .then(r => r.json())
      .then(d => setIgAccount(d.account))
      .catch(() => {});
  }, []);

  const handleSaveNotifs = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    setSaving(false);
    toast.success('Notification preferences saved');
  };

  const handleConnectInstagram = () => {
    const appId      = process.env.NEXT_PUBLIC_INSTAGRAM_APP_ID;
    const redirectUri = encodeURIComponent(`${process.env.NEXT_PUBLIC_APP_URL}/api/instagram/callback`);
    const scope      = 'instagram_basic,instagram_manage_messages,instagram_manage_comments,pages_show_list,pages_read_engagement';
    window.location.href = `https://www.facebook.com/dialog/oauth?client_id=${appId}&redirect_uri=${redirectUri}&scope=${scope}&response_type=code`;
  };

  const handleDisconnect = async () => {
    if (!confirm('Disconnect Instagram? All automations will pause.')) return;
    await fetch('/api/instagram/disconnect', { method: 'POST' });
    setIgAccount(null);
    toast.success('Instagram disconnected');
  };

  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-2xl">

      <FI>
        <h2 className="font-display text-xl font-bold text-white">Settings</h2>
        <p className="text-white/40 text-sm mt-0.5">Manage your account and preferences</p>
      </FI>

      {/* Instagram connection */}
      <FI delay={0.05}>
        <Section title="Instagram Account" desc="Connect your Instagram Business or Creator account">
          {igAccount ? (
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-500 to-violet-600 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                {igAccount.username?.[0]?.toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-white">@{igAccount.username}</div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span className="text-xs text-emerald-400">Connected & Active</span>
                </div>
                {igAccount.followerCount > 0 && (
                  <div className="text-xs text-white/30 mt-0.5">
                    {igAccount.followerCount.toLocaleString()} followers
                  </div>
                )}
              </div>
              <button
                onClick={handleDisconnect}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl glass border border-red-500/20 text-red-400 text-xs font-medium hover:border-red-500/35 hover:bg-red-500/8 transition-all"
              >
                <Unlink className="w-3.5 h-3.5" /> Disconnect
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center text-center py-6">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500/20 to-violet-500/20 border border-pink-500/20 flex items-center justify-center mb-4">
                <Instagram className="w-6 h-6 text-pink-400" />
              </div>
              <h4 className="font-display font-semibold text-white mb-1">No Instagram Connected</h4>
              <p className="text-white/40 text-sm mb-5 max-w-xs">
                Connect your Instagram Business or Creator account to start automating.
              </p>

              <button
                onClick={handleConnectInstagram}
                className="btn-gradient text-white font-semibold px-6 py-3 rounded-xl flex items-center gap-2 text-sm"
              >
                <Instagram className="w-4 h-4" />
                Connect Instagram Account
              </button>

              <div className="flex items-center gap-4 mt-4 text-xs text-white/30">
                <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> Official Meta API</span>
                <span className="flex items-center gap-1"><Lock className="w-3 h-3" /> Token encrypted</span>
              </div>

              <a
                href="https://developers.facebook.com/docs/instagram-api"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 transition-colors"
              >
                <ExternalLink className="w-3 h-3" /> Need a Business account?
              </a>
            </div>
          )}
        </Section>
      </FI>

      {/* Profile */}
      <FI delay={0.1}>
        <Section title="Profile" desc="Your account information synced from Clerk">
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0 overflow-hidden"
            >
              {user?.imageUrl
                ? <img src={user.imageUrl} alt="" className="w-full h-full object-cover" />
                : (user?.firstName?.[0] || 'U')}
            </div>
            <div>
              <div className="text-sm font-semibold text-white">{user?.fullName || 'Your Name'}</div>
              <div className="text-xs text-white/40">{user?.primaryEmailAddress?.emailAddress}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {[
              { icon: User,  label: 'Full Name', value: user?.fullName || '' },
              { icon: Mail,  label: 'Email',     value: user?.primaryEmailAddress?.emailAddress || '' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-xs text-white/40 uppercase tracking-wider font-medium mb-1.5">
                  {f.label}
                </label>
                <div className="flex items-center gap-2 bg-white/4 border border-white/8 rounded-xl px-3 py-2.5">
                  <f.icon className="w-3.5 h-3.5 text-white/30 flex-shrink-0" />
                  <span className="text-sm text-white/60">{f.value || '—'}</span>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-white/25 pt-1">
            To update your profile, visit{' '}
            <a href="https://accounts.clerk.com" target="_blank" className="text-violet-400 hover:text-violet-300">
              Clerk Account Settings →
            </a>
          </p>
        </Section>
      </FI>

      {/* Notifications */}
      <FI delay={0.15}>
        <Section title="Notifications" desc="Choose which emails and push alerts you receive">
          <Toggle
            label="Trial Reminder Emails"
            desc="Get reminded 3 days before trial expires"
            checked={notifs.emailTrialReminder}
            onChange={() => setNotifs(n => ({ ...n, emailTrialReminder: !n.emailTrialReminder }))}
          />
          <div className="h-px bg-white/4" />
          <Toggle
            label="Payment Receipts"
            desc="Email invoice after every payment"
            checked={notifs.emailPaymentReceipt}
            onChange={() => setNotifs(n => ({ ...n, emailPaymentReceipt: !n.emailPaymentReceipt }))}
          />
          <div className="h-px bg-white/4" />
          <Toggle
            label="Weekly Summary Email"
            desc="Automation performance report every Monday"
            checked={notifs.emailWeeklySummary}
            onChange={() => setNotifs(n => ({ ...n, emailWeeklySummary: !n.emailWeeklySummary }))}
          />
          <div className="h-px bg-white/4" />
          <Toggle
            label="New Lead Alert"
            desc="Push notification when a lead is captured"
            checked={notifs.pushNewLead}
            onChange={() => setNotifs(n => ({ ...n, pushNewLead: !n.pushNewLead }))}
          />
          <div className="h-px bg-white/4" />
          <Toggle
            label="DM Milestone Alerts"
            desc="Celebrate every 1,000 DMs sent"
            checked={notifs.pushDmMilestone}
            onChange={() => setNotifs(n => ({ ...n, pushDmMilestone: !n.pushDmMilestone }))}
          />

          <button
            onClick={handleSaveNotifs}
            disabled={saving}
            className="btn-gradient text-white font-semibold px-5 py-2.5 rounded-xl text-sm flex items-center gap-2 disabled:opacity-60 mt-2"
          >
            {saving
              ? <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Saving...</>
              : <><Save className="w-4 h-4" /> Save Preferences</>
            }
          </button>
        </Section>
      </FI>

      {/* Security */}
      <FI delay={0.2}>
        <Section title="Security" desc="Manage your account security settings">
          <div className="space-y-3">
            {[
              { icon: Key,        label: 'Change Password',        desc: 'Update via Clerk account portal',      href: 'https://accounts.clerk.com' },
              { icon: Smartphone, label: 'Two-Factor Auth',        desc: 'Add extra security to your account',   href: 'https://accounts.clerk.com' },
              { icon: Globe,      label: 'Connected Apps',         desc: 'Manage OAuth app permissions',          href: 'https://accounts.clerk.com' },
            ].map(item => (
              <a
                key={item.label}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/4 transition-all group"
              >
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-violet-500/15 transition-all">
                  <item.icon className="w-3.5 h-3.5 text-white/40 group-hover:text-violet-400 transition-colors" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-white/80 group-hover:text-white transition-colors">{item.label}</div>
                  <div className="text-xs text-white/35">{item.desc}</div>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-white/20 group-hover:text-white/50 transition-colors" />
              </a>
            ))}
          </div>
        </Section>
      </FI>
    </div>
  );
}
