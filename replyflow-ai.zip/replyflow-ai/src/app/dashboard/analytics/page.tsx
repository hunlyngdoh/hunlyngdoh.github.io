// src/app/dashboard/analytics/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  TrendingUp, MessageSquare, Users, Heart,
  Repeat2, Bot, Download, Calendar, ArrowUpRight
} from 'lucide-react';

const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

const CHART_TOOLTIP = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass rounded-xl px-3 py-2 border border-white/10 text-xs shadow-card-dark">
      <div className="text-white/50 mb-1.5 font-medium">{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2 mb-0.5">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span className="text-white/60">{p.name}:</span>
          <span className="text-white font-semibold">{p.value.toLocaleString()}</span>
        </div>
      ))}
    </div>
  );
};

const PIE_COLORS = ['#7c3aed', '#d946ef', '#ff2d78', '#06b6d4', '#10b981', '#f59e0b'];

const MOCK_AREA = Array.from({ length: 30 }, (_, i) => ({
  date: `${i + 1}`,
  dms:      Math.floor(80  + Math.random() * 280),
  leads:    Math.floor(10  + Math.random() * 60),
  comments: Math.floor(40  + Math.random() * 120),
  stories:  Math.floor(20  + Math.random() * 80),
}));

const MOCK_PIE = [
  { name: 'Comment AutoDM', value: 42 },
  { name: 'Story Reply',    value: 23 },
  { name: 'Welcome DM',     value: 18 },
  { name: 'Keyword Trigger',value: 10 },
  { name: 'Lead Capture',   value: 7  },
];

const MOCK_BAR = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => ({
  day: d,
  sent:   Math.floor(80 + Math.random() * 200),
  opened: Math.floor(40 + Math.random() * 100),
}));

export default function AnalyticsPage() {
  const [range, setRange]       = useState<'7d' | '30d' | '90d'>('30d');
  const [chartData, setChartData] = useState(MOCK_AREA);
  const [stats, setStats]       = useState<any>(null);

  useEffect(() => {
    fetch('/api/analytics/stats')
      .then(r => r.json())
      .then(setStats)
      .catch(() => {});
  }, []);

  const kpis = [
    { label: 'Total DMs Sent',      value: stats?.allTimeDms     ?? '12,847', icon: MessageSquare, color: '#7c3aed', change: '+18%' },
    { label: 'Leads Captured',      value: stats?.leadsTotal     ?? '1,240',  icon: TrendingUp,    color: '#10b981', change: '+34%' },
    { label: 'Comment Replies',     value: stats?.commentReplies ?? '5,632',  icon: Repeat2,       color: '#d946ef', change: '+12%' },
    { label: 'Story Replies',       value: '2,318',                           icon: Heart,         color: '#ff2d78', change: '+9%'  },
    { label: 'Active Automations',  value: stats?.activeFlows    ?? '6',      icon: Bot,           color: '#f59e0b'               },
    { label: 'Avg. Response Time',  value: '1.4s',                            icon: Users,         color: '#06b6d4'               },
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6">

      {/* Header */}
      <FI className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-white">Analytics</h2>
          <p className="text-white/40 text-sm mt-0.5">Track your automation performance</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Range picker */}
          <div className="flex glass rounded-xl border border-white/8 overflow-hidden">
            {(['7d','30d','90d'] as const).map(r => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-3 py-1.5 text-xs font-medium transition-all ${
                  range === r
                    ? 'bg-violet-600 text-white'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass border border-white/8 text-xs text-white/50 hover:text-white transition-all">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
        </div>
      </FI>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {kpis.map((k, i) => (
          <FI key={k.label} delay={i * 0.05}>
            <div className="glass rounded-2xl p-4 border border-white/5 hover:border-white/10 transition-all group relative overflow-hidden">
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl"
                style={{ background: `radial-gradient(ellipse at 20% 20%, ${k.color}10 0%, transparent 65%)` }}
              />
              <div className="flex items-center justify-between mb-2 relative">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: `${k.color}18`, border: `1px solid ${k.color}25` }}>
                  <k.icon className="w-3.5 h-3.5" style={{ color: k.color }} />
                </div>
                {k.change && (
                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-0.5">
                    <ArrowUpRight className="w-3 h-3" />{k.change}
                  </span>
                )}
              </div>
              <div className="font-display text-xl font-bold text-white stat-number relative">{k.value}</div>
              <div className="text-xs text-white/35 mt-0.5 relative">{k.label}</div>
            </div>
          </FI>
        ))}
      </div>

      {/* Main area chart */}
      <FI delay={0.2}>
        <div className="glass rounded-2xl p-5 border border-white/5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-semibold text-white">Performance Over Time</h3>
              <p className="text-xs text-white/35 mt-0.5">DMs, leads, comments & story replies — last {range}</p>
            </div>
            <div className="flex flex-wrap gap-3 text-xs text-white/40">
              {[
                { label: 'DMs', color: '#7c3aed' },
                { label: 'Leads', color: '#10b981' },
                { label: 'Comments', color: '#d946ef' },
                { label: 'Stories', color: '#ff2d78' },
              ].map(l => (
                <span key={l.label} className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: l.color }} />
                  {l.label}
                </span>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <defs>
                {[
                  { id: 'dms',      color: '#7c3aed' },
                  { id: 'leads',    color: '#10b981' },
                  { id: 'comments', color: '#d946ef' },
                  { id: 'stories',  color: '#ff2d78' },
                ].map(g => (
                  <linearGradient key={g.id} id={g.id} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor={g.color} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={g.color} stopOpacity={0}   />
                  </linearGradient>
                ))}
              </defs>
              <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 10 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CHART_TOOLTIP />} />
              <Area type="monotone" dataKey="dms"      name="DMs"      stroke="#7c3aed" strokeWidth={1.5} fill="url(#dms)"      dot={false} />
              <Area type="monotone" dataKey="leads"    name="Leads"    stroke="#10b981" strokeWidth={1.5} fill="url(#leads)"    dot={false} />
              <Area type="monotone" dataKey="comments" name="Comments" stroke="#d946ef" strokeWidth={1.5} fill="url(#comments)" dot={false} />
              <Area type="monotone" dataKey="stories"  name="Stories"  stroke="#ff2d78" strokeWidth={1.5} fill="url(#stories)"  dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </FI>

      {/* Bottom row: bar + pie */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

        {/* Weekly bar chart */}
        <FI delay={0.25}>
          <div className="glass rounded-2xl p-5 border border-white/5 h-full">
            <h3 className="font-display font-semibold text-white text-sm mb-1">Weekly DM Activity</h3>
            <p className="text-xs text-white/35 mb-5">Sent vs opened this week</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={MOCK_BAR} barGap={4} margin={{ top: 0, right: 5, bottom: 0, left: -20 }}>
                <XAxis dataKey="day" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CHART_TOOLTIP />} />
                <Bar dataKey="sent"   name="Sent"   fill="#7c3aed" radius={[4,4,0,0]} maxBarSize={28} />
                <Bar dataKey="opened" name="Opened" fill="#d946ef" radius={[4,4,0,0]} maxBarSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </FI>

        {/* Automation type distribution */}
        <FI delay={0.3}>
          <div className="glass rounded-2xl p-5 border border-white/5 h-full">
            <h3 className="font-display font-semibold text-white text-sm mb-1">Automation Breakdown</h3>
            <p className="text-xs text-white/35 mb-4">By automation type (% of total)</p>
            <div className="flex items-center gap-5">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie
                    data={MOCK_PIE}
                    cx="50%" cy="50%"
                    innerRadius={48} outerRadius={72}
                    paddingAngle={3}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {MOCK_PIE.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CHART_TOOLTIP />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-2.5">
                {MOCK_PIE.map((entry, i) => (
                  <div key={entry.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: PIE_COLORS[i] }} />
                      <span className="text-xs text-white/55 leading-snug">{entry.name}</span>
                    </div>
                    <span className="text-xs font-semibold text-white">{entry.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </FI>
      </div>
    </div>
  );
}
