// src/app/dashboard/billing/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CreditCard, Zap, Clock, CheckCircle2, AlertTriangle,
  Download, ChevronRight, ArrowUpRight, Shield, RefreshCw,
  Calendar, ReceiptText, Crown, Sparkles, X, Check
} from 'lucide-react';
import { PLANS } from '@/lib/plans';
import { format, formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

/* ─── Fade in ───────────────────────────── */
const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

/* ─── Cancel confirmation modal ─────────── */
function CancelModal({ onConfirm, onClose }: { onConfirm: () => void; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(6px)' }}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-sm glass-strong rounded-2xl p-6 border border-red-500/20"
      >
        <div className="w-12 h-12 rounded-2xl bg-red-500/15 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-5 h-5 text-red-400" />
        </div>
        <h3 className="font-display text-lg font-bold text-center mb-2">Cancel Subscription?</h3>
        <p className="text-white/50 text-sm text-center mb-6">
          Your automations will keep running until the end of your billing period. You can resubscribe anytime.
        </p>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl glass border border-white/10 text-sm font-medium hover:bg-white/5 transition-all">
            Keep Plan
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm font-medium hover:bg-red-500/30 transition-all"
          >
            Yes, Cancel
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Upgrade Plan Modal ─────────────────── */
function UpgradeModal({ currentPlan, onClose }: { currentPlan: string; onClose: () => void }) {
  const [loading, setLoading] = useState<string | null>(null);

  const handleUpgrade = async (planId: string) => {
    setLoading(planId);
    try {
      const res = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, paymentMethod: 'upi' }),
      });
      const data = await res.json();
      if (!data.orderId) throw new Error(data.error);

      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: data.amount, currency: 'INR',
        name: 'ReplyFlow AI', description: `Upgrade to ${planId} Plan`,
        order_id: data.orderId,
        theme: { color: '#7c3aed' },
        handler: async (response: any) => {
          const verify = await fetch('/api/razorpay/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...response, planId }),
          });
          const result = await verify.json();
          if (result.success) {
            toast.success('Plan upgraded successfully!');
            window.location.reload();
          }
        },
      };
      // @ts-ignore
      new (window as any).Razorpay(options).open();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        className="w-full max-w-2xl glass-strong rounded-3xl p-6 border border-violet-500/20"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-display text-xl font-bold">Change Plan</h3>
          <button onClick={onClose} className="text-white/40 hover:text-white text-2xl leading-none">×</button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {PLANS.map(plan => {
            const isCurrent = plan.id.toUpperCase() === currentPlan;
            return (
              <div
                key={plan.id}
                className={`rounded-2xl p-4 border transition-all ${
                  isCurrent
                    ? 'border-violet-500/40 bg-violet-500/10'
                    : 'border-white/8 glass hover:border-white/15'
                }`}
              >
                {isCurrent && (
                  <div className="text-xs text-violet-300 font-semibold mb-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Current Plan
                  </div>
                )}
                <div className="font-display font-bold text-lg text-white">{plan.name}</div>
                <div className="font-display text-2xl font-bold my-2" style={{ color: plan.gradientFrom }}>
                  {plan.priceDisplay}<span className="text-sm text-white/40 font-normal">/mo</span>
                </div>
                <div className="text-xs text-white/40 mb-4">{plan.instagramAccounts}</div>
                <button
                  onClick={() => !isCurrent && handleUpgrade(plan.id)}
                  disabled={isCurrent || loading === plan.id}
                  className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    isCurrent
                      ? 'bg-violet-500/20 text-violet-300 cursor-default'
                      : 'btn-gradient text-white hover:shadow-glow-sm'
                  }`}
                >
                  {loading === plan.id ? 'Processing...' : isCurrent ? 'Current' : 'Switch Plan'}
                </button>
              </div>
            );
          })}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Main Page ─────────────────────────── */
export default function BillingPage() {
  const [sub, setSub] = useState<any>(null);
  const [payments, setPayments] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [trialData, setTrialData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showCancel, setShowCancel] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  useEffect(() => {
    // Load Razorpay script
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);

    Promise.all([
      fetch('/api/users/subscription').then(r => r.json()),
      fetch('/api/users/payments').then(r => r.json()),
      fetch('/api/users/invoices').then(r => r.json()),
      fetch('/api/trial').then(r => r.json()),
    ]).then(([s, p, inv, t]) => {
      setSub(s.subscription);
      setPayments(p.payments || []);
      setInvoices(inv.invoices || []);
      setTrialData(t);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const handleCancel = async () => {
    try {
      const res = await fetch('/api/users/subscription/cancel', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        toast.success('Subscription will cancel at period end');
        setSub((s: any) => ({ ...s, cancelAtPeriodEnd: true }));
      }
    } catch { toast.error('Failed to cancel'); }
    setShowCancel(false);
  };

  if (loading) {
    return (
      <div className="p-6 space-y-4">
        {[1,2,3].map(i => (
          <div key={i} className="h-28 rounded-2xl shimmer-loading" />
        ))}
      </div>
    );
  }

  const planInfo = PLANS.find(p => p.id === sub?.plan?.toLowerCase()) || PLANS[1];
  const statusMap: Record<string, { label: string; className: string }> = {
    ACTIVE:   { label: 'Active',      className: 'badge-active' },
    TRIAL:    { label: 'Free Trial',  className: 'badge-trial' },
    EXPIRED:  { label: 'Expired',     className: 'badge-expired' },
    CANCELED: { label: 'Canceled',    className: 'badge-canceled' },
    PAST_DUE: { label: 'Past Due',    className: 'badge-expired' },
  };
  const statusInfo = statusMap[sub?.status || 'TRIAL'] || statusMap.TRIAL;

  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-4xl">

      {/* Current plan card */}
      <FI>
        <div className="relative glass rounded-3xl p-6 border border-white/6 overflow-hidden">
          <div
            className="absolute inset-0 opacity-30 rounded-3xl"
            style={{ background: `radial-gradient(ellipse at 80% 50%, ${planInfo.gradientFrom}20, transparent 60%)` }}
          />
          <div className="relative">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="font-display text-2xl font-bold text-white">{planInfo.name} Plan</h2>
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusInfo.className}`}>
                    {statusInfo.label}
                  </span>
                  {sub?.cancelAtPeriodEnd && (
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/20">
                      Cancels at period end
                    </span>
                  )}
                </div>
                <p className="text-white/40 text-sm">{planInfo.tagline}</p>
              </div>
              <div className="text-right">
                <div className="font-display text-3xl font-bold text-white">{planInfo.priceDisplay}</div>
                <div className="text-white/40 text-sm mt-0.5">per month · auto-renews</div>
              </div>
            </div>

            {/* Period info */}
            {sub?.currentPeriodEnd && (
              <div className="flex flex-wrap gap-4 mb-5">
                <div className="flex items-center gap-2 text-sm text-white/50">
                  <Calendar className="w-4 h-4 text-violet-400" />
                  {sub.status === 'TRIAL' ? 'Trial ends' : 'Renews'}: {' '}
                  <span className="text-white/80 font-medium">
                    {format(new Date(sub.currentPeriodEnd), 'MMM d, yyyy')}
                  </span>
                  <span className="text-white/30">
                    ({formatDistanceToNow(new Date(sub.currentPeriodEnd), { addSuffix: true })})
                  </span>
                </div>
              </div>
            )}

            {/* Plan features quick */}
            <div className="flex flex-wrap gap-2 mb-6">
              {planInfo.features.filter(f => f.included).slice(0, 5).map(f => (
                <span key={f.text} className="text-xs text-white/50 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/4">
                  <Check className="w-3 h-3 text-emerald-400" />{f.text}
                </span>
              ))}
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setShowUpgrade(true)}
                className="btn-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-xl flex items-center gap-2"
              >
                <Crown className="w-4 h-4" />
                {sub?.status === 'TRIAL' ? 'Subscribe Now' : 'Change Plan'}
              </button>

              {sub?.status === 'ACTIVE' && !sub?.cancelAtPeriodEnd && (
                <button
                  onClick={() => setShowCancel(true)}
                  className="text-sm font-medium px-5 py-2.5 rounded-xl glass border border-white/10 hover:border-red-500/30 text-white/60 hover:text-red-300 transition-all"
                >
                  Cancel Subscription
                </button>
              )}

              {sub?.cancelAtPeriodEnd && (
                <button
                  onClick={async () => {
                    await fetch('/api/users/subscription/reactivate', { method: 'POST' });
                    toast.success('Subscription reactivated!');
                    setSub((s: any) => ({ ...s, cancelAtPeriodEnd: false }));
                  }}
                  className="text-sm font-semibold px-5 py-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 transition-all flex items-center gap-2"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Reactivate
                </button>
              )}
            </div>
          </div>
        </div>
      </FI>

      {/* Trial expired CTA */}
      {trialData?.trialExpired && sub?.status !== 'ACTIVE' && (
        <FI delay={0.1}>
          <div className="rounded-2xl p-5 border border-orange-500/25 bg-orange-500/8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-orange-300 mb-1">Free trial expired</div>
                  <div className="text-sm text-white/50">Subscribe to re-enable all automations and keep your data.</div>
                </div>
              </div>
              <Link href="/pricing" className="flex-shrink-0 btn-gradient text-white font-bold px-6 py-2.5 rounded-xl flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> Subscribe Now
              </Link>
            </div>
          </div>
        </FI>
      )}

      {/* Payment methods */}
      <FI delay={0.15}>
        <div className="glass rounded-2xl p-5 border border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-white text-sm">Payment Methods</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { label: 'UPI',         icon: '⚡', sub: '7673962811@ybl',     color: '#5f259f' },
              { label: 'PhonePe',     icon: '📱', sub: 'Instant payment',    color: '#5f259f' },
              { label: 'Google Pay',  icon: 'G',  sub: 'Instant payment',    color: '#4285f4' },
              { label: 'Razorpay',    icon: 'R',  sub: 'Cards & Net Banking', color: '#3395ff' },
              { label: 'Cards',       icon: '💳', sub: 'Visa, MC, RuPay',   color: '#7c3aed' },
              { label: 'Net Banking', icon: '🏦', sub: 'All Indian banks',   color: '#059669' },
            ].map(pm => (
              <div
                key={pm.label}
                className="flex items-center gap-3 p-3 rounded-xl glass border border-white/5"
              >
                <span className="text-lg">{pm.icon}</span>
                <div>
                  <div className="text-xs font-semibold text-white">{pm.label}</div>
                  <div className="text-xs text-white/35">{pm.sub}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs text-white/30">
            <Shield className="w-3 h-3" /> Payments secured by Razorpay · 256-bit SSL
          </div>
        </div>
      </FI>

      {/* Invoices */}
      <FI delay={0.2}>
        <div className="glass rounded-2xl border border-white/5 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
            <h3 className="font-display font-semibold text-white text-sm">Billing History</h3>
            <span className="text-xs text-white/30">{invoices.length} invoices</span>
          </div>

          {invoices.length === 0 ? (
            <div className="py-12 text-center">
              <ReceiptText className="w-8 h-8 text-white/15 mx-auto mb-3" />
              <p className="text-sm text-white/30">No invoices yet</p>
              <p className="text-xs text-white/20 mt-1">Invoices will appear here after your first payment</p>
            </div>
          ) : (
            <div className="divide-y divide-white/4">
              {invoices.map(inv => (
                <div key={inv.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-white/2 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center">
                      <ReceiptText className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">{inv.invoiceNo}</div>
                      <div className="text-xs text-white/35">{format(new Date(inv.issuedAt), 'MMM d, yyyy')}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-semibold text-white">₹{Math.round(inv.amount + inv.taxAmount)}</div>
                      <div className="text-xs text-emerald-400">Paid</div>
                    </div>
                    <button className="p-1.5 rounded-lg hover:bg-white/5 text-white/30 hover:text-violet-400 transition-all">
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </FI>

      {/* Modals */}
      <AnimatePresence>
        {showCancel && <CancelModal onConfirm={handleCancel} onClose={() => setShowCancel(false)} />}
        {showUpgrade && <UpgradeModal currentPlan={sub?.plan || ''} onClose={() => setShowUpgrade(false)} />}
      </AnimatePresence>
    </div>
  );
}
