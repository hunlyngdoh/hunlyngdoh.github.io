// src/app/dashboard/automations/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Zap, MessageSquare, Bell, Users, Bot, TrendingUp,
  Repeat2, Pencil, Trash2, Play, Pause, Search, Filter,
  ChevronRight, Sparkles, X, Check, Clock
} from 'lucide-react';
import toast from 'react-hot-toast';

const AUTO_TYPES = [
  { id: 'COMMENT_AUTO_DM', label: 'Comment AutoDM',  icon: MessageSquare, color: '#7c3aed', desc: 'Send DM when someone comments on your post' },
  { id: 'STORY_REPLY',     label: 'Story Reply',      icon: Bell,          color: '#d946ef', desc: 'Auto-reply when someone reacts to your story' },
  { id: 'WELCOME_DM',      label: 'Welcome DM',       icon: Users,         color: '#06b6d4', desc: 'Greet new followers automatically' },
  { id: 'KEYWORD_TRIGGER', label: 'Keyword Trigger',  icon: Zap,           color: '#f59e0b', desc: 'Trigger automation on specific keywords' },
  { id: 'LEAD_CAPTURE',    label: 'Lead Capture',     icon: TrendingUp,    color: '#10b981', desc: 'Collect email/phone from DM conversations' },
  { id: 'AI_REPLY',        label: 'AI Reply',         icon: Bot,           color: '#ff2d78', desc: 'Let AI respond contextually to any DM' },
];

/* ─── Create/Edit Modal ─────────────────── */
function AutomationModal({
  flow, onClose, onSave,
}: { flow?: any; onClose: () => void; onSave: (data: any) => void }) {
  const isEdit = !!flow;
  const [form, setForm] = useState({
    name:            flow?.name || '',
    type:            flow?.type || 'COMMENT_AUTO_DM',
    replyMessage:    flow?.replyMessage || '',
    triggerKeywords: (flow?.triggerKeywords || []).join(', '),
    delaySeconds:    flow?.delaySeconds || 0,
    isActive:        flow?.isActive ?? true,
  });
  const [loading, setLoading] = useState(false);

  const selectedType = AUTO_TYPES.find(t => t.id === form.type)!;

  const handleSave = async () => {
    if (!form.name.trim() || !form.replyMessage.trim()) {
      toast.error('Name and reply message are required');
      return;
    }
    setLoading(true);
    try {
      const payload = {
        ...form,
        triggerKeywords: form.triggerKeywords
          .split(',')
          .map(k => k.trim())
          .filter(Boolean),
      };
      const res = await fetch(
        isEdit ? `/api/automations/${flow.id}` : '/api/automations',
        {
          method:  isEdit ? 'PATCH' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify(payload),
        }
      );
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      toast.success(isEdit ? 'Automation updated!' : 'Automation created!');
      onSave(data.flow);
    } catch (err: any) {
      toast.error(err.message || 'Failed to save');
    } finally {
      setLoading(false);
    }
  };

  const AI_TEMPLATES = [
    'Hey {{name}}! 👋 Thanks for commenting. DM me the word "INFO" to learn more!',
    'Hi {{name}}! Love your support 💜 Reply with "YES" and I\'ll send you the exclusive details!',
    'Thanks for reaching out, {{name}}! I\'d love to connect. Type "LINK" to get the resource.',
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ y: 40, opacity: 0, scale: 0.97 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 280 }}
        className="w-full max-w-lg glass-strong rounded-3xl border border-white/8 overflow-hidden max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/6 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: `${selectedType.color}18`, border: `1px solid ${selectedType.color}25` }}
            >
              <selectedType.icon className="w-4 h-4" style={{ color: selectedType.color }} />
            </div>
            <h3 className="font-display font-bold text-white">{isEdit ? 'Edit' : 'New'} Automation</h3>
          </div>
          <button onClick={onClose} className="text-white/40 hover:text-white text-2xl leading-none">×</button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto no-scrollbar flex-1 p-6 space-y-5">

          {/* Name */}
          <div>
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
              Automation Name
            </label>
            <input
              type="text"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="e.g. Comment AutoDM for Reel #1"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/50 transition-colors"
            />
          </div>

          {/* Type */}
          <div>
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
              Automation Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              {AUTO_TYPES.map(t => (
                <button
                  key={t.id}
                  onClick={() => setForm(f => ({ ...f, type: t.id }))}
                  className={`flex items-center gap-2 p-3 rounded-xl border text-left transition-all ${
                    form.type === t.id
                      ? 'border-violet-500/40 bg-violet-500/10'
                      : 'border-white/6 glass hover:border-white/15'
                  }`}
                >
                  <t.icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: t.color }} />
                  <span className="text-xs font-medium text-white/80">{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Keyword triggers */}
          {(form.type === 'KEYWORD_TRIGGER' || form.type === 'COMMENT_AUTO_DM') && (
            <div>
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
                Trigger Keywords <span className="text-white/30 normal-case">(comma separated)</span>
              </label>
              <input
                type="text"
                value={form.triggerKeywords}
                onChange={e => setForm(f => ({ ...f, triggerKeywords: e.target.value }))}
                placeholder="e.g. price, info, buy, link"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/50 transition-colors"
              />
            </div>
          )}

          {/* Reply message */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                Reply Message
              </label>
              <span className="text-xs text-white/30">Use {'{{name}}'} for personalization</span>
            </div>
            <textarea
              value={form.replyMessage}
              onChange={e => setForm(f => ({ ...f, replyMessage: e.target.value }))}
              rows={4}
              placeholder="Hi {{name}}! Thanks for reaching out..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/50 transition-colors resize-none"
            />
            {/* AI templates */}
            <div className="mt-2">
              <div className="text-xs text-white/30 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-violet-400" /> AI Templates
              </div>
              <div className="space-y-1">
                {AI_TEMPLATES.map((t, i) => (
                  <button
                    key={i}
                    onClick={() => setForm(f => ({ ...f, replyMessage: t }))}
                    className="w-full text-left text-xs text-white/40 hover:text-white/70 py-1 px-2 rounded-lg hover:bg-white/5 transition-all leading-relaxed"
                  >
                    {t.slice(0, 70)}...
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Delay */}
          <div>
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
              Reply Delay: <span className="text-violet-300">{form.delaySeconds}s</span>
            </label>
            <input
              type="range"
              min={0} max={300} step={10}
              value={form.delaySeconds}
              onChange={e => setForm(f => ({ ...f, delaySeconds: Number(e.target.value) }))}
              className="w-full accent-violet-500"
            />
            <div className="flex justify-between text-xs text-white/25 mt-1">
              <span>Instant</span><span>5 min</span>
            </div>
          </div>

          {/* Active toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-white">Active</div>
              <div className="text-xs text-white/35">Start automation immediately</div>
            </div>
            <button
              onClick={() => setForm(f => ({ ...f, isActive: !f.isActive }))}
              className={`relative w-12 h-6 rounded-full transition-all duration-300 ${form.isActive ? 'bg-violet-600' : 'bg-white/10'}`}
            >
              <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${form.isActive ? 'left-7' : 'left-1'}`} />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 px-6 py-4 border-t border-white/6 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl glass border border-white/10 text-sm font-medium hover:bg-white/5 transition-all">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={loading}
            className="flex-1 py-3 rounded-xl btn-gradient text-white text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? (
              <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Saving...</>
            ) : (
              <><Check className="w-4 h-4" /> {isEdit ? 'Save Changes' : 'Create Automation'}</>
            )}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Flow Card ─────────────────────────── */
function FlowCard({ flow, onEdit, onDelete, onToggle }: any) {
  const typeInfo = AUTO_TYPES.find(t => t.id === flow.type) || AUTO_TYPES[0];

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="glass rounded-2xl p-5 border border-white/5 hover:border-white/10 transition-all duration-300 group"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: `${typeInfo.color}15`, border: `1px solid ${typeInfo.color}22` }}
          >
            <typeInfo.icon className="w-4 h-4" style={{ color: typeInfo.color }} />
          </div>
          <div>
            <div className="text-sm font-semibold text-white">{flow.name}</div>
            <div className="text-xs text-white/35 mt-0.5">{typeInfo.label}</div>
          </div>
        </div>

        {/* Toggle */}
        <button
          onClick={() => onToggle(flow.id)}
          className={`relative w-11 h-5.5 h-[22px] rounded-full transition-all duration-300 flex-shrink-0 ${flow.isActive ? 'bg-violet-600' : 'bg-white/10'}`}
        >
          <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${flow.isActive ? 'left-[26px]' : 'left-0.5'}`} />
        </button>
      </div>

      {/* Reply preview */}
      <p className="text-xs text-white/35 mb-4 line-clamp-2 leading-relaxed bg-white/3 rounded-lg p-2.5 font-mono">
        {flow.replyMessage}
      </p>

      {/* Stats */}
      <div className="flex items-center gap-4 mb-4">
        <div className="text-center">
          <div className="text-sm font-bold text-white">{flow.totalTriggered}</div>
          <div className="text-xs text-white/30">Triggered</div>
        </div>
        <div className="text-center">
          <div className="text-sm font-bold text-white">{flow.totalReplied}</div>
          <div className="text-xs text-white/30">Sent</div>
        </div>
        {flow.delaySeconds > 0 && (
          <div className="flex items-center gap-1 text-xs text-white/30">
            <Clock className="w-3 h-3" />{flow.delaySeconds}s delay
          </div>
        )}
        <div className="ml-auto">
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${flow.isActive ? 'badge-active' : 'badge-canceled'}`}>
            {flow.isActive ? 'Running' : 'Paused'}
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => onEdit(flow)}
          className="flex-1 py-2 rounded-xl glass border border-white/8 text-xs font-medium text-white/60 hover:text-white flex items-center justify-center gap-1.5 transition-all"
        >
          <Pencil className="w-3 h-3" /> Edit
        </button>
        <button
          onClick={() => onDelete(flow.id)}
          className="flex-1 py-2 rounded-xl glass border border-red-500/15 text-xs font-medium text-red-400/60 hover:text-red-400 hover:border-red-500/30 flex items-center justify-center gap-1.5 transition-all"
        >
          <Trash2 className="w-3 h-3" /> Delete
        </button>
      </div>
    </motion.div>
  );
}

/* ─── Main Page ─────────────────────────── */
export default function AutomationsPage() {
  const [flows, setFlows]   = useState<any[]>([]);
  const [editFlow, setEditFlow] = useState<any>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch]   = useState('');
  const [filter, setFilter]   = useState<string>('ALL');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/automations').then(r => r.json()).then(d => {
      setFlows(d.flows || []);
      setLoading(false);
    });
  }, []);

  const handleSave = (flow: any) => {
    setFlows(prev => {
      const exists = prev.find(f => f.id === flow.id);
      return exists ? prev.map(f => f.id === flow.id ? flow : f) : [flow, ...prev];
    });
    setShowCreate(false);
    setEditFlow(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this automation?')) return;
    await fetch(`/api/automations/${id}`, { method: 'DELETE' });
    setFlows(prev => prev.filter(f => f.id !== id));
    toast.success('Automation deleted');
  };

  const handleToggle = async (id: string) => {
    setFlows(prev => prev.map(f => f.id === id ? { ...f, isActive: !f.isActive } : f));
    await fetch(`/api/automations/${id}/toggle`, { method: 'PATCH' });
  };

  const filtered = flows.filter(f => {
    const matchSearch = f.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'ALL' || f.type === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="p-4 sm:p-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6"
      >
        <div>
          <h2 className="font-display text-xl font-bold text-white">Automation Flows</h2>
          <p className="text-white/40 text-sm mt-0.5">
            {flows.filter(f => f.isActive).length} active · {flows.length} total
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="btn-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-xl flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> New Automation
        </button>
      </motion.div>

      {/* Search & filter */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="flex flex-col sm:flex-row gap-3 mb-6"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search automations..."
            className="w-full bg-white/5 border border-white/8 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/40 transition-colors"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {['ALL', ...AUTO_TYPES.map(t => t.id)].map(type => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all flex-shrink-0 ${
                filter === type
                  ? 'bg-violet-600 text-white'
                  : 'glass border border-white/8 text-white/50 hover:text-white'
              }`}
            >
              {type === 'ALL' ? 'All' : AUTO_TYPES.find(t => t.id === type)?.label || type}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Empty state */}
      {!loading && filtered.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20"
        >
          <Zap className="w-12 h-12 text-white/10 mx-auto mb-4" />
          <h3 className="font-display text-lg font-semibold text-white/40 mb-2">
            {search ? 'No automations match your search' : 'No automations yet'}
          </h3>
          <p className="text-white/25 text-sm mb-6">
            {search ? 'Try a different search term' : 'Create your first automation to start growing on autopilot'}
          </p>
          {!search && (
            <button
              onClick={() => setShowCreate(true)}
              className="btn-gradient text-white text-sm font-semibold px-6 py-3 rounded-xl inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Create First Automation
            </button>
          )}
        </motion.div>
      )}

      {/* Grid */}
      <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {filtered.map(flow => (
            <FlowCard
              key={flow.id}
              flow={flow}
              onEdit={f => setEditFlow(f)}
              onDelete={handleDelete}
              onToggle={handleToggle}
            />
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Modals */}
      <AnimatePresence>
        {(showCreate || editFlow) && (
          <AutomationModal
            flow={editFlow}
            onClose={() => { setShowCreate(false); setEditFlow(null); }}
            onSave={handleSave}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
