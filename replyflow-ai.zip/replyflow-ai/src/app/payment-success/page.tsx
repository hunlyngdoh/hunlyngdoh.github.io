// src/app/payment-success/page.tsx
'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { CheckCircle2, Zap, ArrowRight, Download, LayoutDashboard } from 'lucide-react';
import { PLANS } from '@/lib/plans';
import confetti from 'canvas-confetti';

export default function PaymentSuccessPage() {
  const params  = useSearchParams();
  const planId  = params.get('plan') || 'pro';
  const payId   = params.get('payment') || '';
  const plan    = PLANS.find(p => p.id === planId) || PLANS[1];
  const [fired, setFired] = useState(false);

  useEffect(() => {
    if (!fired) {
      setFired(true);
      // Confetti burst
      const end = Date.now() + 2000;
      const colors = ['#7c3aed', '#d946ef', '#ff2d78', '#ffffff'];
      (function frame() {
        confetti({ particleCount: 3, angle: 60,  spread: 55, origin: { x: 0 }, colors });
        confetti({ particleCount: 3, angle: 120, spread: 55, origin: { x: 1 }, colors });
        if (Date.now() < end) requestAnimationFrame(frame);
      })();
    }
  }, [fired]);

  return (
    <div className="min-h-screen mesh-gradient flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md text-center"
      >
        {/* Success icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
          className="w-20 h-20 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(52,211,153,0.3)]"
        >
          <CheckCircle2 className="w-10 h-10 text-emerald-400" />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <h1 className="font-display text-3xl font-bold text-white mb-2">Payment Successful! 🎉</h1>
          <p className="text-white/50 text-base mb-8">
            Welcome to ReplyFlow AI {plan.name}. Your account is fully activated.
          </p>
        </motion.div>

        {/* Plan card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-2xl p-5 border mb-6"
          style={{ borderColor: `${plan.gradientFrom}30` }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: `${plan.gradientFrom}20` }}
              >
                <Zap className="w-4 h-4" style={{ color: plan.gradientFrom }} />
              </div>
              <div className="text-left">
                <div className="text-sm font-semibold text-white">{plan.name} Plan</div>
                <div className="text-xs text-white/40">{plan.instagramAccounts}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-display font-bold text-white">{plan.priceDisplay}/mo</div>
              <div className="text-xs text-emerald-400">Active</div>
            </div>
          </div>
          {payId && (
            <div className="text-xs text-white/30 font-mono text-left">
              Payment ID: {payId.slice(0, 20)}...
            </div>
          )}
        </motion.div>

        {/* What's next */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-2xl p-4 border border-white/5 mb-6 text-left"
        >
          <div className="text-xs text-white/40 uppercase tracking-wider font-medium mb-3">What's next?</div>
          <div className="space-y-2.5">
            {[
              'Connect your Instagram account',
              'Create your first AutoDM flow',
              'Set up keyword triggers',
              'Watch leads come in automatically',
            ].map((step, i) => (
              <div key={step} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-violet-500/20 border border-violet-500/30 flex items-center justify-center flex-shrink-0 text-xs text-violet-300 font-bold">
                  {i + 1}
                </div>
                <span className="text-sm text-white/70">{step}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex gap-3"
        >
          <button className="flex-1 py-3 rounded-xl glass border border-white/10 text-sm font-medium flex items-center justify-center gap-2 hover:bg-white/5 transition-all text-white/70">
            <Download className="w-4 h-4" /> Invoice
          </button>
          <Link href="/dashboard" className="flex-1 btn-gradient text-white font-semibold py-3 rounded-xl text-sm flex items-center justify-center gap-2">
            <LayoutDashboard className="w-4 h-4" /> Go to Dashboard
          </Link>
        </motion.div>
      </motion.div>
    </div>
  );
}
