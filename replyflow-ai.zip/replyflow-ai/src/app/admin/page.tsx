// src/app/admin/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Users, CreditCard, TrendingUp, Zap, Search,
  Shield, Ban, Clock, CheckCircle2, XCircle,
  BarChart3, ArrowUpRight, RefreshCw, ChevronDown
} from 'lucide-react';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const FI = ({ children, delay = 0, className = '' }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className={className}
  >
    {children}
  </motion.div>
);

export default function AdminPage() {
  const [users, setUsers]     = useState<any[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [search, setSearch]   = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/admin/users').then(r => r.json()),
      fetch('/api/admin/metrics').then(r => r.json()),
    ]).then(([u, m]) => {
      setUsers(u.users || []);
      setMetrics(m);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const handleBan = async (userId: string, isBanned: boolean) => {
    await fetch('/api/admin/users', {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ userId, status: isBanned ? 'ACTIVE' : 'BANNED' }),
    });
    setUsers(prev => prev.map(u =>
      u.id === userId ? { ...u, status: isBanned ? 'ACTIVE' : 'BANNED' } : u
    ));
    toast.success(isBanned ? 'User unbanned' : 'User banned');
  };

  const handleTrialExtend = async (userId: string) => {
    await fetch('/api/admin/extend-trial', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ userId, days: 7 }),
    });
    toast.success('Trial extended by 7 days');
  };

  const filtered = users.filter(u =>
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.name?.toLowerCase().includes(search.toLowerCase())
  );

  const subStatusColor: Record<string, string> = {
    ACTIVE:   'badge-active',
    TRIAL:    'badge-trial',
    EXPIRED:  'badge-expired',
    CANCELED: 'badge-canceled',
    PAST_DUE: 'badge-expired',
  };

  return (
    <div className="min-h-screen mesh-gradient p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <FI className="flex items-center gap-3 mb-8">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" fill="white" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-white">Admin Panel</h1>
            <p className="text-white/40 text-sm">ReplyFlow AI — Internal Dashboard</p>
          </div>
          <div className="ml-auto px-3 py-1.5 rounded-full text-xs font-semibold text-red-300 bg-red-500/15 border border-red-500/25 flex items-center gap-1.5">
            <Shield className="w-3 h-3" /> Admin Only
          </div>
        </FI>

        {/* Metric cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Total Users',      value: metrics?.totalUsers    ?? '—', icon: Users,      color: '#7c3aed', change: '+12%' },
            { label: 'Active Subs',      value: metrics?.activeSubs    ?? '—', icon: CheckCircle2, color: '#10b981', change: '+8%' },
            { label: 'Trial Users',      value: metrics?.trialUsers    ?? '—', icon: Clock,       color: '#f59e0b'              },
            { label: 'Monthly Revenue',  value: metrics?.mrr ? `₹${metrics.mrr.toLocaleString('en-IN')}` : '—', icon: TrendingUp, color: '#ff2d78', change: '+24%' },
          ].map((card, i) => (
            <FI key={card.label} delay={i * 0.05}>
              <div className="glass rounded-2xl p-4 border border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${card.color}18` }}>
                    <card.icon className="w-4 h-4" style={{ color: card.color }} />
                  </div>
                  {card.change && <span className="text-xs font-semibold text-emerald-400">{card.change}</span>}
                </div>
                <div className="font-display text-2xl font-bold text-white">{card.value}</div>
                <div className="text-xs text-white/40 mt-0.5">{card.label}</div>
              </div>
            </FI>
          ))}
        </div>

        {/* Users table */}
        <FI delay={0.2}>
          <div className="glass rounded-2xl border border-white/5 overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-white/5">
              <h3 className="font-display font-semibold text-white">All Users</h3>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search users..."
                  className="bg-white/5 border border-white/8 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-violet-500/40 w-64 transition-colors"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[700px]">
                <thead>
                  <tr className="border-b border-white/4">
                    {['User', 'Plan', 'Status', 'Joined', 'Actions'].map(h => (
                      <th key={h} className="text-left py-3 px-4 text-xs text-white/30 font-semibold uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-white/3">
                        {Array.from({ length: 5 }).map((_, j) => (
                          <td key={j} className="px-4 py-3">
                            <div className="h-4 rounded shimmer-loading" />
                          </td>
                        ))}
                      </tr>
                    ))
                  ) : filtered.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-12 text-white/30 text-sm">No users found</td>
                    </tr>
                  ) : (
                    filtered.map(user => (
                      <tr key={user.id} className="border-b border-white/3 hover:bg-white/2 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                              {user.name?.[0] || user.email[0]}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-white">{user.name || 'No name'}</div>
                              <div className="text-xs text-white/35">{user.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs font-medium text-white/70">
                            {user.subscription?.plan || 'No plan'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${subStatusColor[user.subscription?.status || 'TRIAL'] || 'badge-trial'}`}>
                              {user.subscription?.status || 'TRIAL'}
                            </span>
                            {user.status === 'BANNED' && (
                              <span className="text-xs text-red-400 font-medium">Banned</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs text-white/35">
                          {format(new Date(user.createdAt), 'MMM d, yyyy')}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleTrialExtend(user.id)}
                              className="p-1.5 rounded-lg hover:bg-white/5 text-white/30 hover:text-amber-400 transition-all"
                              title="Extend trial"
                            >
                              <Clock className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleBan(user.id, user.status === 'BANNED')}
                              className="p-1.5 rounded-lg hover:bg-white/5 transition-all"
                              style={{ color: user.status === 'BANNED' ? '#34d399' : 'rgba(255,255,255,0.3)' }}
                              title={user.status === 'BANNED' ? 'Unban user' : 'Ban user'}
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </FI>
      </div>
    </div>
  );
}
