// src/app/signup/page.tsx
import { SignUp } from '@clerk/nextjs';
import Link from 'next/link';
import { Zap, Check } from 'lucide-react';

export const metadata = { title: 'Start Free Trial — ReplyFlow AI' };

export default function SignupPage() {
  return (
    <div className="min-h-screen mesh-gradient flex flex-col lg:flex-row">
      {/* Left panel — benefits */}
      <div className="hidden lg:flex lg:w-[42%] flex-col justify-center px-12 xl:px-16 relative overflow-hidden">
        <div className="absolute w-80 h-80 top-1/4 -left-20 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute w-60 h-60 bottom-1/4 right-0 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <Link href="/" className="flex items-center gap-2.5 mb-10">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center shadow-glow-sm">
              <Zap className="w-4 h-4 text-white" fill="white" />
            </div>
            <span className="font-display font-bold text-xl">Reply<span className="text-gradient">Flow</span> AI</span>
          </Link>

          <h2 className="font-display text-4xl font-bold text-white leading-tight mb-4">
            Start automating<br />
            <span className="text-gradient">in 2 minutes.</span>
          </h2>
          <p className="text-white/50 text-base mb-10">
            Join 8,000+ Indian creators and businesses growing on Instagram autopilot.
          </p>

          <ul className="space-y-4 mb-10">
            {[
              { text: '7-day free trial — no card needed',     color: '#10b981' },
              { text: 'Full Pro access during trial',          color: '#7c3aed' },
              { text: 'Unlimited AutoDMs & comment replies',   color: '#d946ef' },
              { text: 'AI-powered DM assistant included',      color: '#f59e0b' },
              { text: 'UPI, PhonePe, Google Pay supported',    color: '#06b6d4' },
              { text: 'Cancel anytime, no questions asked',    color: '#ff2d78' },
            ].map(item => (
              <li key={item.text} className="flex items-center gap-3">
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: `${item.color}20`, border: `1px solid ${item.color}35` }}
                >
                  <Check className="w-3 h-3" style={{ color: item.color }} />
                </div>
                <span className="text-white/70 text-sm">{item.text}</span>
              </li>
            ))}
          </ul>

          {/* Social proof */}
          <div className="glass rounded-2xl p-4 border border-white/8">
            <div className="flex items-center gap-1 mb-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <svg key={i} className="w-3.5 h-3.5 fill-yellow-400" viewBox="0 0 20 20">
                  <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                </svg>
              ))}
              <span className="text-xs text-white/40 ml-1">4.9/5 · 8,000+ users</span>
            </div>
            <p className="text-white/60 text-xs italic">
              &ldquo;Best Instagram tool I&apos;ve ever used. Made ₹50K in leads in first month!&rdquo;
            </p>
            <p className="text-white/30 text-xs mt-1">— Priya S., Mumbai creator</p>
          </div>
        </div>
      </div>

      {/* Right panel — Clerk form */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 lg:p-8">
        {/* Mobile logo */}
        <Link href="/" className="flex items-center gap-2 mb-6 lg:hidden">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#ff2d78] flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" fill="white" />
          </div>
          <span className="font-display font-bold text-lg">Reply<span className="text-gradient">Flow</span> AI</span>
        </Link>

        <SignUp
          appearance={{
            layout: { socialButtonsPlacement: 'top', socialButtonsVariant: 'iconButton' },
            elements: {
              rootBox:              'w-full max-w-md',
              card:                 'bg-surface-2 border border-white/8 shadow-card-dark rounded-3xl backdrop-blur-xl',
              headerTitle:          'font-display font-bold text-white text-xl',
              headerSubtitle:       'text-white/40 text-sm',
              socialButtonsIconButton: 'border border-white/10 hover:border-violet-500/40 bg-white/4 hover:bg-white/8 transition-all rounded-xl',
              dividerLine:          'bg-white/8',
              dividerText:          'text-white/30 text-xs',
              formFieldLabel:       'text-white/60 text-xs font-medium uppercase tracking-wider',
              formFieldInput:       'bg-white/5 border border-white/10 text-white rounded-xl focus:border-violet-500/50 placeholder:text-white/20 text-sm',
              formButtonPrimary:    'bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 hover:opacity-90 transition-opacity rounded-xl font-semibold text-white text-sm py-3',
              footerActionLink:     'text-violet-400 hover:text-violet-300 font-medium',
              alertText:            'text-red-400 text-sm',
              internal:             'font-body',
            },
          }}
          redirectUrl="/dashboard"
          signInUrl="/login"
        />
      </div>
    </div>
  );
}
