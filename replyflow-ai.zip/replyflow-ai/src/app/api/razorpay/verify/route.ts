// src/app/api/razorpay/verify/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import { addDays, addMonths } from 'date-fns';
import { PLANS, TRIAL_DAYS } from '@/lib/plans';

export async function POST(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      planId,
    } = body;

    // ── 1. Verify signature ──────────────────────────
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      console.error('[Razorpay] Signature mismatch');
      return NextResponse.json({ success: false, error: 'Invalid signature' }, { status: 400 });
    }

    // ── 2. Get user ──────────────────────────────────
    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    const plan = PLANS.find(p => p.id === planId);
    if (!plan) {
      return NextResponse.json({ success: false, error: 'Invalid plan' }, { status: 400 });
    }

    // ── 3. Update payment record ─────────────────────
    await prisma.payment.updateMany({
      where: { gatewayOrderId: razorpay_order_id, userId: user.id },
      data: {
        status:           'SUCCESS',
        gatewayPaymentId: razorpay_payment_id,
      },
    });

    // ── 4. Get the updated payment for invoice ───────
    const payment = await prisma.payment.findFirst({
      where: { gatewayOrderId: razorpay_order_id, userId: user.id },
    });

    // ── 5. Create / update subscription ─────────────
    const now = new Date();
    const periodEnd = addMonths(now, 1);

    await prisma.subscription.upsert({
      where:  { userId: user.id },
      create: {
        userId:             user.id,
        plan:               plan.id.toUpperCase() as any,
        status:             'ACTIVE',
        currentPeriodStart: now,
        currentPeriodEnd:   periodEnd,
        razorpaySubId:      razorpay_payment_id,
      },
      update: {
        plan:               plan.id.toUpperCase() as any,
        status:             'ACTIVE',
        currentPeriodStart: now,
        currentPeriodEnd:   periodEnd,
        razorpaySubId:      razorpay_payment_id,
        cancelAtPeriodEnd:  false,
        canceledAt:         null,
      },
    });

    // ── 6. Create invoice ────────────────────────────
    if (payment) {
      const invoiceNo = `RF-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      await prisma.invoice.create({
        data: {
          userId:    user.id,
          paymentId: payment.id,
          invoiceNo,
          amount:    plan.price,
          currency:  'INR',
          taxAmount: plan.price * 0.18,
          status:    'PAID',
          issuedAt:  now,
        },
      });
    }

    // ── 7. Send notification ─────────────────────────
    await prisma.notification.create({
      data: {
        userId:  user.id,
        title:   '🎉 Subscription Activated!',
        message: `Your ${plan.name} plan is now active. All automations are running.`,
        type:    'SUCCESS',
        link:    '/dashboard/billing',
      },
    });

    return NextResponse.json({
      success: true,
      planId:  plan.id,
      message: 'Payment verified and subscription activated',
    });

  } catch (error: any) {
    console.error('[Razorpay Verify]', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
