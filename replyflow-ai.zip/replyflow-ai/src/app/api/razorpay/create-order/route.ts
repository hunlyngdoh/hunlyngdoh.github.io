// src/app/api/razorpay/create-order/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/prisma';
import { PLANS } from '@/lib/plans';

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { planId, paymentMethod } = body;

    // Validate plan
    const plan = PLANS.find(p => p.id === planId);
    if (!plan) {
      return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
    }

    // Get user
    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Amount in paise (INR × 100), include 18% GST
    const amountWithGST = Math.round(plan.price * 1.18 * 100);

    // Create Razorpay order
    const order = await razorpay.orders.create({
      amount:   amountWithGST,
      currency: 'INR',
      receipt:  `rf_${user.id}_${Date.now()}`,
      notes: {
        userId:        user.id,
        planId:        plan.id,
        planName:      plan.name,
        paymentMethod: paymentMethod || 'upi',
        appName:       'ReplyFlow AI',
      },
    });

    // Store pending payment
    await prisma.payment.create({
      data: {
        userId:          user.id,
        amount:          plan.price * 1.18,
        currency:        'INR',
        status:          'PENDING',
        gateway:         'RAZORPAY',
        gatewayOrderId:  order.id,
        plan:            plan.id.toUpperCase() as any,
        metadata: {
          orderId:       order.id,
          planId:        plan.id,
          paymentMethod,
          amountPaise:   amountWithGST,
        },
      },
    });

    return NextResponse.json({
      orderId:   order.id,
      amount:    amountWithGST,
      currency:  'INR',
      keyId:     process.env.RAZORPAY_KEY_ID,
      planName:  plan.name,
      planPrice: plan.priceDisplay,
    });

  } catch (error: any) {
    console.error('[Razorpay Create Order]', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create order' },
      { status: 500 }
    );
  }
}
