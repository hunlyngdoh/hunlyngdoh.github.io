// src/app/api/admin/extend-trial/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { addDays } from 'date-fns';

export async function POST(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const admin = await prisma.user.findUnique({ where: { clerkId } });
    if (!admin || (admin.role !== 'ADMIN' && admin.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { userId, days = 7 } = await req.json();
    if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 });

    const trial = await prisma.trialStatus.findUnique({ where: { userId } });
    if (!trial) return NextResponse.json({ error: 'No trial found' }, { status: 404 });

    const base       = trial.isExpired ? new Date() : trial.expiresAt;
    const newExpiry  = addDays(base, days);

    await prisma.trialStatus.update({
      where: { userId },
      data:  { expiresAt: newExpiry, isExpired: false },
    });

    await prisma.subscription.updateMany({
      where: { userId },
      data:  { currentPeriodEnd: newExpiry, status: 'TRIAL' },
    });

    // Re-enable automations
    await prisma.automationFlow.updateMany({
      where: { userId },
      data:  { isActive: true },
    });

    await prisma.notification.create({
      data: {
        userId,
        title:   '🎁 Your trial has been extended!',
        message: `An admin extended your trial by ${days} days.`,
        type:    'SUCCESS',
        link:    '/dashboard',
      },
    });

    return NextResponse.json({ success: true, newExpiry });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
