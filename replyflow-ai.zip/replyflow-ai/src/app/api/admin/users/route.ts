// src/app/api/admin/users/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

async function requireAdmin(clerkId: string) {
  const user = await prisma.user.findUnique({ where: { clerkId } });
  if (!user || user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') {
    throw new Error('Forbidden');
  }
  return user;
}

/* GET all users with subscription info */
export async function GET(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    await requireAdmin(clerkId);

    const { searchParams } = new URL(req.url);
    const page  = parseInt(searchParams.get('page')  || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const skip  = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        skip,
        take:    limit,
        orderBy: { createdAt: 'desc' },
        include: {
          subscription:    true,
          trialStatus:     true,
          _count: {
            select: { automationFlows: true, payments: true },
          },
        },
      }),
      prisma.user.count(),
    ]);

    return NextResponse.json({ users, total, page, pages: Math.ceil(total / limit) });
  } catch (err: any) {
    const status = err.message === 'Forbidden' ? 403 : 500;
    return NextResponse.json({ error: err.message }, { status });
  }
}

/* PATCH update user status (ban/unban/suspend) */
export async function PATCH(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    await requireAdmin(clerkId);

    const { userId, status, role } = await req.json();
    if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 });

    const updated = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(status && { status }),
        ...(role   && { role }),
      },
    });

    return NextResponse.json({ user: updated });
  } catch (err: any) {
    const status = err.message === 'Forbidden' ? 403 : 500;
    return NextResponse.json({ error: err.message }, { status });
  }
}
