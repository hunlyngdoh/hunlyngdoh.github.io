// src/app/api/admin/metrics/route.ts
import { NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { startOfMonth, subMonths } from 'date-fns';

export async function GET() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const admin = await prisma.user.findUnique({ where: { clerkId } });
    if (!admin || (admin.role !== 'ADMIN' && admin.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const now         = new Date();
    const monthStart  = startOfMonth(now);
    const lastMonth   = startOfMonth(subMonths(now, 1));

    const [
      totalUsers,
      newUsersThisMonth,
      activeSubs,
      trialUsers,
      expiredTrials,
      canceledSubs,
      mrrData,
      planDist,
      recentPayments,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { createdAt: { gte: monthStart } } }),
      prisma.subscription.count({ where: { status: 'ACTIVE' } }),
      prisma.subscription.count({ where: { status: 'TRIAL' } }),
      prisma.trialStatus.count({ where: { isExpired: true } }),
      prisma.subscription.count({ where: { status: 'CANCELED' } }),
      prisma.payment.aggregate({
        where: { status: 'SUCCESS', createdAt: { gte: monthStart } },
        _sum:  { amount: true },
      }),
      prisma.subscription.groupBy({
        by:     ['plan'],
        where:  { status: 'ACTIVE' },
        _count: { plan: true },
      }),
      prisma.payment.findMany({
        where:   { status: 'SUCCESS' },
        orderBy: { createdAt: 'desc' },
        take:    10,
        include: { user: { select: { email: true, name: true } } },
      }),
    ]);

    const mrr = mrrData._sum.amount || 0;

    // Monthly revenue for last 6 months
    const monthlyRevenue = await Promise.all(
      Array.from({ length: 6 }, (_, i) => {
        const start = startOfMonth(subMonths(now, 5 - i));
        const end   = startOfMonth(subMonths(now, 4 - i));
        return prisma.payment.aggregate({
          where:  { status: 'SUCCESS', createdAt: { gte: start, lt: end } },
          _sum:   { amount: true },
        }).then(r => ({ month: start, revenue: r._sum.amount || 0 }));
      })
    );

    return NextResponse.json({
      totalUsers,
      newUsersThisMonth,
      activeSubs,
      trialUsers,
      expiredTrials,
      canceledSubs,
      mrr: Math.round(mrr),
      planDistribution: planDist,
      monthlyRevenue,
      recentPayments,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
