import { NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

export async function POST() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const user = await prisma.user.findUnique({ where: { clerkId }, include: { subscription: true } });
    if (!user?.subscription) return NextResponse.json({ error: 'No subscription' }, { status: 404 });
    await prisma.subscription.update({
      where: { userId: user.id },
      data: { cancelAtPeriodEnd: true, canceledAt: new Date() },
    });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
