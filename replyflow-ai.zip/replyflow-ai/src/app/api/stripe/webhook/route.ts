// src/app/api/stripe/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { prisma } from '@/lib/prisma';
import { addMonths } from 'date-fns';
import { PLANS } from '@/lib/plans';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

export const config = { api: { bodyParser: false } };

export async function POST(req: NextRequest) {
  const body      = await req.text();
  const signature = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    console.error('[Stripe Webhook] Signature error:', err.message);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  try {
    switch (event.type) {

      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId  = session.metadata?.userId;
        const planId  = session.metadata?.planId;
        if (!userId || !planId) break;

        const plan = PLANS.find(p => p.id === planId);
        if (!plan) break;

        const now = new Date();
        await prisma.subscription.upsert({
          where:  { userId },
          create: {
            userId,
            plan:               plan.id.toUpperCase() as any,
            status:             'ACTIVE',
            currentPeriodStart: now,
            currentPeriodEnd:   addMonths(now, 1),
            stripeSubId:        session.subscription as string,
          },
          update: {
            plan:               plan.id.toUpperCase() as any,
            status:             'ACTIVE',
            currentPeriodStart: now,
            currentPeriodEnd:   addMonths(now, 1),
            stripeSubId:        session.subscription as string,
            cancelAtPeriodEnd:  false,
          },
        });

        // Record payment
        await prisma.payment.create({
          data: {
            userId,
            amount:           plan.price * 1.18,
            currency:         'INR',
            status:           'SUCCESS',
            gateway:          'STRIPE',
            gatewayPaymentId: session.payment_intent as string,
            plan:             plan.id.toUpperCase() as any,
          },
        });
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        const subId   = invoice.subscription as string;
        if (subId) {
          await prisma.subscription.updateMany({
            where: { stripeSubId: subId },
            data:  { status: 'PAST_DUE' },
          });
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await prisma.subscription.updateMany({
          where: { stripeSubId: sub.id },
          data:  { status: 'CANCELED', canceledAt: new Date() },
        });
        break;
      }

      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription;
        await prisma.subscription.updateMany({
          where: { stripeSubId: sub.id },
          data: {
            cancelAtPeriodEnd:  sub.cancel_at_period_end,
            currentPeriodEnd:   new Date(sub.current_period_end * 1000),
            status:             sub.status === 'active' ? 'ACTIVE' : 'PAST_DUE',
          },
        });
        break;
      }
    }
  } catch (err: any) {
    console.error('[Stripe Webhook] Handler error:', err);
  }

  return NextResponse.json({ received: true });
}
