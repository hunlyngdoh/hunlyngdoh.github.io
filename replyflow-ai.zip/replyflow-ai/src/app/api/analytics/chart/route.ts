// src/app/api/analytics/chart/route.ts
import { NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { startOfDay, subDays, format } from 'date-fns';

export async function GET() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    // Build 7-day range
    const days = Array.from({ length: 7 }, (_, i) => startOfDay(subDays(new Date(), 6 - i)));

    const stats = await prisma.dailyStats.findMany({
      where: {
        userId: user.id,
        date:   { gte: days[0] },
      },
    });

    const data = days.map(day => {
      const record = stats.find(s => s.date.toISOString() === day.toISOString());
      return {
        date:     format(day, 'EEE'),
        dms:      record?.dmsSent         || 0,
        leads:    record?.leadsCapture    || 0,
        comments: record?.commentsReplied || 0,
        stories:  record?.storyReplies    || 0,
      };
    });

    return NextResponse.json({ data });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
