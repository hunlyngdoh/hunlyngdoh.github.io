// src/app/api/analytics/stats/route.ts
import { NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { startOfDay, subDays } from 'date-fns';

export async function GET() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({
      where:   { clerkId },
      include: { automationFlows: true },
    });
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const todayStart = startOfDay(new Date());

    // Today's stats from DailyStats table
    const todayStats = await prisma.dailyStats.findUnique({
      where: { userId_date: { userId: user.id, date: todayStart } },
    });

    // All-time totals
    const allTimeStats = await prisma.dailyStats.aggregate({
      where:  { userId: user.id },
      _sum:   { dmsSent: true, leadsCapture: true, commentsReplied: true },
    });

    const activeFlows = user.automationFlows.filter(f => f.isActive).length;
    const totalFlows  = user.automationFlows.length;

    return NextResponse.json({
      dmsSentToday:    todayStats?.dmsSent       || 0,
      commentReplies:  todayStats?.commentsReplied || 0,
      leadsToday:      todayStats?.leadsCapture  || 0,
      leadsTotal:      allTimeStats._sum.leadsCapture   || 0,
      allTimeDms:      allTimeStats._sum.dmsSent        || 0,
      activeFlows,
      totalFlows,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
