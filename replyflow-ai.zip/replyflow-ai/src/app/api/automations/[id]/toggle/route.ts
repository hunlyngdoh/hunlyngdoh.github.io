// src/app/api/automations/[id]/toggle/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

export async function PATCH(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const flow = await prisma.automationFlow.findFirst({ where: { id: params.id, userId: user.id } });
    if (!flow) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const updated = await prisma.automationFlow.update({
      where: { id: params.id },
      data:  { isActive: !flow.isActive },
    });

    return NextResponse.json({ flow: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
