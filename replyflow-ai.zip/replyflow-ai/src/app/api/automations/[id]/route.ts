// src/app/api/automations/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

async function getAuthorizedFlow(clerkId: string, flowId: string) {
  const user = await prisma.user.findUnique({ where: { clerkId } });
  if (!user) return null;
  return prisma.automationFlow.findFirst({ where: { id: flowId, userId: user.id } });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const flow = await getAuthorizedFlow(clerkId, params.id);
    if (!flow) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const body   = await req.json();
    const update = await prisma.automationFlow.update({
      where: { id: params.id },
      data: {
        name:            body.name            ?? flow.name,
        type:            body.type            ?? flow.type,
        replyMessage:    body.replyMessage    ?? flow.replyMessage,
        triggerKeywords: body.triggerKeywords ?? flow.triggerKeywords,
        delaySeconds:    body.delaySeconds    ?? flow.delaySeconds,
        isActive:        body.isActive        ?? flow.isActive,
        settings:        body.settings        ?? flow.settings,
      },
    });

    return NextResponse.json({ flow: update });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const flow = await getAuthorizedFlow(clerkId, params.id);
    if (!flow) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    await prisma.automationFlow.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
