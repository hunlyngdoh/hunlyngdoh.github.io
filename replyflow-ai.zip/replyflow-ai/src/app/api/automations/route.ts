// src/app/api/automations/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

/* GET all automations for user */
export async function GET() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const flows = await prisma.automationFlow.findMany({
      where:   { userId: user.id },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ flows });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/* POST create new automation */
export async function POST(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({
      where:   { clerkId },
      include: { subscription: true },
    });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    // Check subscription
    const sub = user.subscription;
    if (!sub || (sub.status !== 'ACTIVE' && sub.status !== 'TRIAL')) {
      return NextResponse.json({ error: 'Active subscription required' }, { status: 403 });
    }

    const body = await req.json();
    const { name, type, replyMessage, triggerKeywords, delaySeconds, isActive } = body;

    if (!name || !type || !replyMessage) {
      return NextResponse.json({ error: 'name, type, replyMessage are required' }, { status: 400 });
    }

    const flow = await prisma.automationFlow.create({
      data: {
        userId:          user.id,
        name,
        type,
        replyMessage,
        triggerKeywords: triggerKeywords || [],
        delaySeconds:    delaySeconds || 0,
        isActive:        isActive ?? true,
      },
    });

    // Log event
    await prisma.analyticsEvent.create({
      data: { userId: user.id, eventType: 'AUTOMATION_CREATED', metadata: { flowId: flow.id, type } },
    });

    return NextResponse.json({ flow }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
