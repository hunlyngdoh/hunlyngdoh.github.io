// src/app/api/phonepe/callback/route.ts
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import { addMonths } from 'date-fns';
import { PLANS } from '@/lib/plans';

const PHONEPE_SALT_KEY   = process.env.PHONEPE_SALT_KEY!;
const PHONEPE_SALT_INDEX = process.env.PHONEPE_SALT_INDEX || '1';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { response: base64Response } = body;
    const xVerify = req.headers.get('X-VERIFY') || '';

    // Verify checksum
    const [receivedHash] = xVerify.split('###');
    const expectedHash = crypto
      .createHash('sha256')
      .update(`${base64Response}${PHONEPE_SALT_KEY}`)
      .digest('hex');

    if (receivedHash !== expectedHash) {
      console.error('[PhonePe Callback] Checksum mismatch');
      return NextResponse.json({ error: 'Invalid checksum' }, { status: 400 });
    }

    const decoded  = JSON.parse(Buffer.from(base64Response, 'base64').toString('utf-8'));
    const { code, data } = decoded;
    const txnId = data?.merchantTransactionId;

    // Find pending payment
    const payment = await prisma.payment.findFirst({
      where: { gatewayOrderId: txnId },
      include: { user: true },
    });

    if (!payment) {
      console.warn('[PhonePe Callback] Payment not found:', txnId);
      return NextResponse.json({ message: 'OK' });
    }

    if (code === 'PAYMENT_SUCCESS') {
      // Update payment
      await prisma.payment.update({
        where: { id: payment.id },
        data: {
          status:           'SUCCESS',
          gatewayPaymentId: data?.transactionId,
        },
      });

      const planId = (payment.metadata as any)?.planId;
      const plan   = PLANS.find(p => p.id === planId);

      if (plan) {
        const now = new Date();
        await prisma.subscription.upsert({
          where:  { userId: payment.userId },
          create: {
            userId:             payment.userId,
            plan:               plan.id.toUpperCase() as any,
            status:             'ACTIVE',
            currentPeriodStart: now,
            currentPeriodEnd:   addMonths(now, 1),
          },
          update: {
            plan:               plan.id.toUpperCase() as any,
            status:             'ACTIVE',
            currentPeriodStart: now,
            currentPeriodEnd:   addMonths(now, 1),
            cancelAtPeriodEnd:  false,
          },
        });

        // Invoice
        const invoiceNo = `RF-PP-${Date.now()}`;
        await prisma.invoice.create({
          data: {
            userId:    payment.userId,
            paymentId: payment.id,
            invoiceNo,
            amount:    plan.price,
            currency:  'INR',
            taxAmount: plan.price * 0.18,
            status:    'PAID',
          },
        });

        // Notification
        await prisma.notification.create({
          data: {
            userId:  payment.userId,
            title:   '✅ PhonePe Payment Successful',
            message: `${plan.name} plan activated via PhonePe.`,
            type:    'SUCCESS',
            link:    '/dashboard/billing',
          },
        });
      }
    } else {
      await prisma.payment.update({
        where: { id: payment.id },
        data: { status: 'FAILED', failureReason: code },
      });
    }

    return NextResponse.json({ message: 'OK' });
  } catch (error: any) {
    console.error('[PhonePe Callback]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
