// src/app/api/phonepe/initiate/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import { PLANS } from '@/lib/plans';

const PHONEPE_MERCHANT_ID = process.env.PHONEPE_MERCHANT_ID!;
const PHONEPE_SALT_KEY     = process.env.PHONEPE_SALT_KEY!;
const PHONEPE_SALT_INDEX   = process.env.PHONEPE_SALT_INDEX || '1';
const PHONEPE_BASE_URL     = process.env.PHONEPE_ENV === 'production'
  ? 'https://api.phonepe.com/apis/hermes'
  : 'https://api-preprod.phonepe.com/apis/pg-sandbox';

export async function POST(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { planId } = await req.json();
    const plan = PLANS.find(p => p.id === planId);
    if (!plan) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { clerkId } });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const transactionId = `RF_PP_${user.id}_${Date.now()}`;
    const amountPaise   = Math.round(plan.price * 1.18 * 100);
    const appUrl        = process.env.NEXT_PUBLIC_APP_URL!;

    const payload = {
      merchantId:         PHONEPE_MERCHANT_ID,
      merchantTransactionId: transactionId,
      merchantUserId:     user.id,
      amount:             amountPaise,
      redirectUrl:        `${appUrl}/payment-success?gateway=phonepe&txn=${transactionId}`,
      redirectMode:       'REDIRECT',
      callbackUrl:        `${appUrl}/api/phonepe/callback`,
      mobileNumber:       '',
      paymentInstrument: { type: 'PAY_PAGE' },
    };

    const base64Payload = Buffer.from(JSON.stringify(payload)).toString('base64');
    const checksum = crypto
      .createHash('sha256')
      .update(`${base64Payload}/pg/v1/pay${PHONEPE_SALT_KEY}`)
      .digest('hex') + `###${PHONEPE_SALT_INDEX}`;

    const response = await fetch(`${PHONEPE_BASE_URL}/pg/v1/pay`, {
      method:  'POST',
      headers: {
        'Content-Type':   'application/json',
        'X-VERIFY':       checksum,
        'X-MERCHANT-ID':  PHONEPE_MERCHANT_ID,
        accept:           'application/json',
      },
      body: JSON.stringify({ request: base64Payload }),
    });

    const data = await response.json();
    if (!data.success) throw new Error(data.message || 'PhonePe initiation failed');

    // Store pending payment
    await prisma.payment.create({
      data: {
        userId:         user.id,
        amount:         plan.price * 1.18,
        currency:       'INR',
        status:         'PENDING',
        gateway:        'PHONEPE',
        gatewayOrderId: transactionId,
        plan:           plan.id.toUpperCase() as any,
        metadata: { transactionId, planId },
      },
    });

    return NextResponse.json({
      redirectUrl: data.data?.instrumentResponse?.redirectInfo?.url,
      transactionId,
    });

  } catch (error: any) {
    console.error('[PhonePe Initiate]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
