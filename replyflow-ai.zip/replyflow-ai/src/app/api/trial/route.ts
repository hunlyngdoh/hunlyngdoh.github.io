// src/app/api/trial/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { addDays, differenceInHours, isPast } from 'date-fns';
import { TRIAL_DAYS } from '@/lib/plans';

/* GET — fetch trial status for current user */
export async function GET() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({
      where: { clerkId },
      include: { trialStatus: true, subscription: true },
    });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const trial = user.trialStatus;
    const sub   = user.subscription;

    // Active paid subscription overrides trial
    if (sub?.status === 'ACTIVE') {
      return NextResponse.json({
        status:          'active',
        plan:            sub.plan,
        periodEnd:       sub.currentPeriodEnd,
        trialActive:     false,
        trialExpired:    false,
        daysRemaining:   null,
        hoursRemaining:  null,
      });
    }

    if (!trial) {
      return NextResponse.json({ status: 'no_trial', trialActive: false, trialExpired: false });
    }

    const now        = new Date();
    const expired    = isPast(trial.expiresAt);
    const hoursLeft  = expired ? 0 : Math.max(0, differenceInHours(trial.expiresAt, now));
    const daysLeft   = expired ? 0 : Math.max(0, Math.ceil(hoursLeft / 24));

    // Auto-expire in DB if past due
    if (expired && !trial.isExpired) {
      await prisma.trialStatus.update({
        where: { userId: user.id },
        data:  { isExpired: true },
      });
      // Suspend automations
      await prisma.automationFlow.updateMany({
        where:  { userId: user.id },
        data:   { isActive: false },
      });
    }

    return NextResponse.json({
      status:         expired ? 'expired' : 'trial',
      trialActive:    !expired,
      trialExpired:   expired,
      startedAt:      trial.startedAt,
      expiresAt:      trial.expiresAt,
      daysRemaining:  daysLeft,
      hoursRemaining: hoursLeft,
      totalDays:      TRIAL_DAYS,
    });

  } catch (error: any) {
    console.error('[Trial GET]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

/* POST — start trial for new user */
export async function POST() {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const user = await prisma.user.findUnique({
      where:   { clerkId },
      include: { trialStatus: true, subscription: true },
    });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    // Already has active sub
    if (user.subscription?.status === 'ACTIVE') {
      return NextResponse.json({ error: 'Already subscribed' }, { status: 400 });
    }

    // Already has trial
    if (user.trialStatus) {
      return NextResponse.json({ error: 'Trial already started' }, { status: 400 });
    }

    const now       = new Date();
    const expiresAt = addDays(now, TRIAL_DAYS);

    const trial = await prisma.trialStatus.create({
      data: { userId: user.id, startedAt: now, expiresAt },
    });

    // Create trial subscription record
    await prisma.subscription.create({
      data: {
        userId:  user.id,
        plan:    'PRO',    // full pro access during trial
        status:  'TRIAL',
        currentPeriodStart: now,
        currentPeriodEnd:   expiresAt,
      },
    });

    // Welcome notification
    await prisma.notification.create({
      data: {
        userId:  user.id,
        title:   '🚀 Your 7-day free trial has started!',
        message: 'You have full Pro access for 7 days. Connect your Instagram to get started.',
        type:    'INFO',
        link:    '/dashboard',
      },
    });

    return NextResponse.json({ success: true, expiresAt, daysRemaining: TRIAL_DAYS });

  } catch (error: any) {
    console.error('[Trial POST]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
