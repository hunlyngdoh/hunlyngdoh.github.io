// src/app/api/webhooks/clerk/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { Webhook } from 'svix';
import { prisma } from '@/lib/prisma';
import { addDays } from 'date-fns';
import { TRIAL_DAYS } from '@/lib/plans';

export async function POST(req: NextRequest) {
  const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET;
  if (!WEBHOOK_SECRET) return NextResponse.json({ error: 'No webhook secret' }, { status: 500 });

  const svix_id        = req.headers.get('svix-id') || '';
  const svix_timestamp = req.headers.get('svix-timestamp') || '';
  const svix_signature = req.headers.get('svix-signature') || '';

  const body = await req.text();

  let event: any;
  try {
    const wh = new Webhook(WEBHOOK_SECRET);
    event = wh.verify(body, { 'svix-id': svix_id, 'svix-timestamp': svix_timestamp, 'svix-signature': svix_signature });
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const { type, data } = event;

  if (type === 'user.created') {
    const email = data.email_addresses?.[0]?.email_address || '';
    const name  = [data.first_name, data.last_name].filter(Boolean).join(' ') || null;

    try {
      const user = await prisma.user.create({
        data: {
          clerkId:   data.id,
          email,
          name,
          avatarUrl: data.image_url || null,
        },
      });

      // Start 7-day trial automatically
      const now       = new Date();
      const expiresAt = addDays(now, TRIAL_DAYS);

      await prisma.trialStatus.create({
        data: { userId: user.id, startedAt: now, expiresAt },
      });

      await prisma.subscription.create({
        data: {
          userId:             user.id,
          plan:               'PRO',
          status:             'TRIAL',
          currentPeriodStart: now,
          currentPeriodEnd:   expiresAt,
        },
      });

      await prisma.notification.create({
        data: {
          userId:  user.id,
          title:   '🎉 Welcome to ReplyFlow AI!',
          message: `Your 7-day free trial has started. Connect your Instagram to begin automating.`,
          type:    'INFO',
          link:    '/dashboard',
        },
      });

      console.log(`[Clerk Webhook] User created: ${user.id} (${email})`);
    } catch (err: any) {
      // User might already exist
      console.error('[Clerk Webhook] user.created error:', err.message);
    }
  }

  if (type === 'user.updated') {
    const email = data.email_addresses?.[0]?.email_address || '';
    const name  = [data.first_name, data.last_name].filter(Boolean).join(' ') || null;

    await prisma.user.updateMany({
      where: { clerkId: data.id },
      data:  { email, name, avatarUrl: data.image_url || null },
    });
  }

  if (type === 'user.deleted') {
    await prisma.user.deleteMany({ where: { clerkId: data.id } });
  }

  return NextResponse.json({ received: true });
}
