// prisma/seed.ts
import { PrismaClient } from '@prisma/client';
import { addDays } from 'date-fns';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user (update clerkId after creating in Clerk)
  const admin = await prisma.user.upsert({
    where:  { email: 'admin@replyflow.ai' },
    update: {},
    create: {
      clerkId: 'user_REPLACE_WITH_CLERK_ID',
      email:   'admin@replyflow.ai',
      name:    'ReplyFlow Admin',
      role:    'SUPER_ADMIN',
    },
  });

  console.log('✅ Admin user:', admin.email);

  // Demo user for testing
  const demo = await prisma.user.upsert({
    where:  { email: 'demo@replyflow.ai' },
    update: {},
    create: {
      clerkId: 'user_DEMO_REPLACE',
      email:   'demo@replyflow.ai',
      name:    'Demo User',
      role:    'USER',
    },
  });

  // Trial for demo user
  await prisma.trialStatus.upsert({
    where:  { userId: demo.id },
    update: {},
    create: {
      userId:    demo.id,
      startedAt: new Date(),
      expiresAt: addDays(new Date(), 7),
    },
  });

  await prisma.subscription.upsert({
    where:  { userId: demo.id },
    update: {},
    create: {
      userId:             demo.id,
      plan:               'PRO',
      status:             'TRIAL',
      currentPeriodStart: new Date(),
      currentPeriodEnd:   addDays(new Date(), 7),
    },
  });

  // Sample automations
  const automationTypes = [
    { name: 'Reel Comment AutoDM',     type: 'COMMENT_AUTO_DM', replyMessage: 'Hey {{name}}! 👋 Thanks for your comment! DM me "INFO" for details.', triggerKeywords: ['price', 'info', 'how'] },
    { name: 'Story Reply Flow',        type: 'STORY_REPLY',     replyMessage: 'Thanks for the reaction, {{name}}! 💜 Want to know more? Reply YES!', triggerKeywords: [] },
    { name: 'New Follower Welcome',    type: 'WELCOME_DM',      replyMessage: 'Welcome to the family, {{name}}! 🎉 Here\'s my free resource link: replyflow.ai', triggerKeywords: [] },
    { name: 'Lead Capture Bot',        type: 'LEAD_CAPTURE',    replyMessage: 'Hey {{name}}! I\'d love to send you my free guide. What\'s your email?', triggerKeywords: ['guide', 'free', 'download'] },
  ];

  for (const auto of automationTypes) {
    await prisma.automationFlow.create({
      data: {
        userId:          demo.id,
        name:            auto.name,
        type:            auto.type as any,
        replyMessage:    auto.replyMessage,
        triggerKeywords: auto.triggerKeywords,
        isActive:        true,
        totalTriggered:  Math.floor(Math.random() * 500),
        totalReplied:    Math.floor(Math.random() * 480),
      },
    });
  }

  // Sample daily stats for charts
  for (let i = 29; i >= 0; i--) {
    const date = addDays(new Date(), -i);
    date.setHours(0, 0, 0, 0);

    await prisma.dailyStats.upsert({
      where:  { userId_date: { userId: demo.id, date } },
      update: {},
      create: {
        userId:          demo.id,
        date,
        dmsSent:         Math.floor(80  + Math.random() * 250),
        commentsReplied: Math.floor(30  + Math.random() * 120),
        storyReplies:    Math.floor(20  + Math.random() * 80),
        leadsCapture:    Math.floor(5   + Math.random() * 35),
        newFollowers:    Math.floor(10  + Math.random() * 50),
      },
    });
  }

  // Welcome notification
  await prisma.notification.create({
    data: {
      userId:  demo.id,
      title:   '🚀 Welcome to ReplyFlow AI!',
      message: 'Your 7-day free trial has started. Connect Instagram to begin.',
      type:    'INFO',
      link:    '/dashboard',
    },
  });

  console.log('✅ Demo user seeded with automations and stats');
  console.log('\n🎉 Seeding complete!');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
